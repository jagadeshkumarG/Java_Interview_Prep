package com.java.InterviewPrep;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InterviewPrepApplicationTests {

	@Test
	void contextLoads() {
	}

}
