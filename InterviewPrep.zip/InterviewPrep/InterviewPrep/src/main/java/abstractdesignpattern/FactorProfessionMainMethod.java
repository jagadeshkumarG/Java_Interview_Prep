package abstractdesignpattern;

public class FactorProfessionMainMethod {

	public static void main(String[] args) {
			ProfessionAbstractFactory factory = new ProfessionAbstractFactory();
			
			Profession doc = factory.getProfession("Doctor");
			doc.print();
			
			Profession tec = factory.getProfession("Teacher");
			tec.print();
			
			Profession engi = factory.getProfession("Engineer");
			engi.print();
	}

}
