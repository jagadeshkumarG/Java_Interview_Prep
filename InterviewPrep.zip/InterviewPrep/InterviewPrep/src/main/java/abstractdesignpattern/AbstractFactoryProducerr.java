package abstractdesignpattern;

public class AbstractFactoryProducerr {
	
//	public static TraineeProfessionAbstractFactory getProfession(boolean isTrainee) {
//		if(isTrainee) {
//			return new TraineeProfessionAbstractFactory();
//		}
//		else {
//			//return ProfessionAbstractFactory();
//		}
//	}

}
