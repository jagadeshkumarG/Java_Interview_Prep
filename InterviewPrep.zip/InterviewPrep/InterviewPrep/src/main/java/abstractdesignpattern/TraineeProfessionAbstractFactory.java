package abstractdesignpattern;

public class TraineeProfessionAbstractFactory {//extends AbstractFactoryProducer {
	
	public Profession getTraineeProfession(String typreOfProfession) {
		if (typreOfProfession == null) {
			return null;
		}
		if(typreOfProfession.equalsIgnoreCase("Teacher")) {
			return new TraineeTeacher();
		}
		else if(typreOfProfession.equalsIgnoreCase("Engineer")) {
			return new TraineeEngineer();
		}
		return null;
	}

}
