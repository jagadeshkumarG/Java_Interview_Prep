package abstractdesignpattern;

public class TraineeTeacher implements Profession{

	@Override
	public void print() {
			System.out.println("in Print of Traineeteacher class");
	}

}
