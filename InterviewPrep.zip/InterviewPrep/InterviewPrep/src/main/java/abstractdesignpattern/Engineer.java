package abstractdesignpattern;

public class Engineer implements Profession{

	@Override
	public void print() {
			System.out.println("In print of Engineer class");
	}

}
