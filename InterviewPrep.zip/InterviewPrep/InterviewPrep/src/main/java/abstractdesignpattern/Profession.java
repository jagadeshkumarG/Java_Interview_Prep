package abstractdesignpattern;

public interface Profession {
	
	void print();

}
