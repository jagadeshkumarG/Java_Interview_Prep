package singletondesignpattern;

public class EagerInitilization {

	// Singleton class with Eager initilization
	private static EagerInitilization eagerInit = new EagerInitilization();

	private EagerInitilization() {

	}

	public static EagerInitilization getEagerInitilization() {
		return eagerInit;
	}

}
