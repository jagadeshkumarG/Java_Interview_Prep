package singletondesignpattern;

public class MainForAllSingletonClassesInThisPackage {

	public static void main(String[] args) {

		EagerInitilization eagerInit = EagerInitilization.getEagerInitilization();
		LazyInitilization lazyInit = LazyInitilization.getLazyInitilization();
		// lazyInit has an issue when multiple threads access it will fail, So we added
		// synchronizedSingleTon
		SynchronizedSingleTon synchronizedSingleTon = SynchronizedSingleTon.getSynchronizedSingleTon();
		// synchronizedSingleTon has an issue it is a very expensive because it uses
		// locks on threads and allows only single shared thread, So we implemented
		// DoubleLockedSingleton.
		DoubleLockedSingleton doubleLockedSingleton = DoubleLockedSingleton.getDoubleLockedSingleton();
		// DoubleLockedSingleton is thread safe and currently using in the market/industry.
	}

}