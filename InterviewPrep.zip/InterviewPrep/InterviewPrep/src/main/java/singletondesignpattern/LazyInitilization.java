package singletondesignpattern;

public class LazyInitilization {

	// Singleton class with Eager initilization
	private static LazyInitilization lazyInit;

	private LazyInitilization() {

	}
	public static LazyInitilization getLazyInitilization() {
		if (lazyInit == null) {
			lazyInit = new LazyInitilization();
		}
		return lazyInit;
	}

}
