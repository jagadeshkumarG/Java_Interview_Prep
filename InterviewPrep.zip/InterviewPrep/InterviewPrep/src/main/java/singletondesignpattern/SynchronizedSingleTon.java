package singletondesignpattern;

public class SynchronizedSingleTon {

	// Singleton class with Synchronization initilization
	private static SynchronizedSingleTon syncSingleTon;

	private SynchronizedSingleTon() {

	}

	public synchronized static SynchronizedSingleTon getSynchronizedSingleTon() {
		if (syncSingleTon == null) {
			syncSingleTon = new SynchronizedSingleTon();
		}
		return syncSingleTon;
	}

}
