package singletondesignpattern;

public class DoubleLockedSingleton {

	// Singleton class with Double Checked initilization

	private static DoubleLockedSingleton doubleLockedSingleton;

	private DoubleLockedSingleton() {

	}

	public static DoubleLockedSingleton getDoubleLockedSingleton() {

		if (doubleLockedSingleton == null) {
			synchronized (DoubleLockedSingleton.class) {
				if (doubleLockedSingleton == null) {
					doubleLockedSingleton = new DoubleLockedSingleton();
				}
			}
		}
		return doubleLockedSingleton;

	}

}
