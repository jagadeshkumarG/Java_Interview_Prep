package factory.designpattern;

public class ProfessionFactory {
	
	public Profession getProfession(String typreOfProfession) {
		if (typreOfProfession == null) {
			return null;
		}
		if(typreOfProfession.equalsIgnoreCase("Doctor")) {
			return new Doctor();
		}
		else if(typreOfProfession.equalsIgnoreCase("Teacher")) {
			return new Teacher();
		}
		else if(typreOfProfession.equalsIgnoreCase("Engineer")) {
			return new Engineer();
		}
		return null;
	}

}
