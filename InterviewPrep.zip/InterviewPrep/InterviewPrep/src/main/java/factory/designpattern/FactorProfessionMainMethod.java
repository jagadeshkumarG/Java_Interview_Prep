package factory.designpattern;

public class FactorProfessionMainMethod {

	public static void main(String[] args) {
			ProfessionFactory factory = new ProfessionFactory();
			
			Profession doc = factory.getProfession("Doctor");
			doc.print();
			
			Profession tec = factory.getProfession("Teacher");
			tec.print();
			
			Profession engi = factory.getProfession("Engineer");
			engi.print();
			
			ShapeInstanceFactory instanceFactory = new ShapeInstanceFactory();
			Shape circleObj = instanceFactory.getShapeInstanceFactory("Circle");
			circleObj.computeArea();
	}

}
