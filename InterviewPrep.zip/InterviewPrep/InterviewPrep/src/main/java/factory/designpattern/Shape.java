package factory.designpattern;

public interface Shape {
	
	public void computeArea();

}
