package factory.designpattern;

public interface Profession {
	
	void print();

}
