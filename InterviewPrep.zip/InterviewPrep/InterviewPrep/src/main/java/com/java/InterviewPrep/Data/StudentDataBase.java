package com.java.InterviewPrep.Data;

import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;

public class StudentDataBase {

    public static Supplier<Student> studenSupplier = () -> {
        return new Student("Jr.NTR", 1, 10, "male", Arrays.asList("Acting", "Dance", "Heroism"));
    };

    public static List<Student> getAllStudents() {


        Student student1 = new Student("Jr.NTR", 1, 10, "male", Arrays.asList("Acting", "Dance", "Heroism"));
        Student student2 = new Student("Ram Charan", 2, 9.8, "male", Arrays.asList("Acting", "Dance", "Heroism"));

        Student student3 = new Student("Nani", 3, 10, "male", Arrays.asList("Acting", "Dance", "Heroism"));
        Student student4 = new Student("Naveen Pollisetty", 4, 9.5, "male", Arrays.asList("Acting", "Dance", "Heroism"));

        Student student5 = new Student("Chiranjeevi", 5, 10, "male", Arrays.asList("Acting", "Dance", "Heroism"));
        Student student6 = new Student("Balayya_Babu", 6, 10, "male", Arrays.asList("Fighting", "Talent", "Vision"));


        List<Student> students = Arrays.asList(student1, student2, student3, student4, student5, student6);
        return students;

    }

}

