package com.java.InterviewPrep.Interviewssss;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class CharCountAccollite {

	public static void main(String[] args) {

		String str = "Hello World";

		String[] split = str.split("");

		Map<String, Long> charCount = Arrays.stream(split)
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		
		System.out.println(charCount);

		charCount.forEach((key, value) -> System.out.println(key + " : " + value));
	}

}
