package com.java.InterviewPrep.CoreJava;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class IteratorOverHashMapExample {

	public static void main(String[] args) {

		HashMap<Integer, String> jaghaMap = new HashMap<>();

		jaghaMap.put(1, "Ayi_Baboiee");
		jaghaMap.put(2, "Sarle_Ra_Babu");
		jaghaMap.put(3, "Balayyababu");
		jaghaMap.put(4, "Atluntadhi_Manathoni");
		jaghaMap.put(5, "Mamulga_Undadhu");
		jaghaMap.put(6, "Enti_Momentuuu...");

		// iterating using forEach
		System.out.println("\nIterating using forEach");
		jaghaMap.forEach((key, value) -> System.out.println(key + " ->" + value));
		
		// Iterating using entrySet() and iterator
		System.out.println("\nIterating using entrySet() and iterator");
		Iterator<Map.Entry<Integer, String>> iterator = jaghaMap.entrySet().iterator();
		while (iterator.hasNext()) {
			Map.Entry<Integer, String> entry = iterator.next();
			System.out.println(entry.getKey() + " -> " + entry.getValue());
		}
		
		//iterator using entrySet() and forEach and lambdas
//		Map<Entry<Integer, String>, Long> collect = jaghaMap.entrySet().stream().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
//		System.out.println("collect : " + collect );
		
		
		//iterator using entrySet() and forEach and lambdas
		System.out.println("\nIterator using entrySet() and forEach and lambdas");
		jaghaMap.entrySet().forEach((entry) -> System.out.println(entry.getKey() + " -> " + entry.getValue()));
		
		//Iterator using entrySet() and simple for-each loop
		System.out.println("\nIterator using entrySet() and simple for-each loop");
		for(Map.Entry<Integer, String> entry: jaghaMap.entrySet()) {
			System.out.println(entry.getKey() + " -> " + entry.getValue());
		}
		
		//Iterating over KeySet()
		System.out.println("\nIterating over KeySet()");
		jaghaMap.keySet().forEach((key) -> System.out.println(key + " -> " + jaghaMap.get(key)));
	}

}
