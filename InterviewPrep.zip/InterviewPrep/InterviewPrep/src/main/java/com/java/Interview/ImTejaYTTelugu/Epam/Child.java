package com.java.Interview.ImTejaYTTelugu.Epam;

public class Child extends Parent {

	public void m1() {
		System.out.println("child m1");
	}

	public void m2() {

		System.out.println("child m2");

	}

	public void m3() {
		System.out.println("child m3");

	}

	public void m4() {
		System.out.println("child m4");

	}

	public void m5() {
		System.out.println("child m5");

	}

	public void m10() {
		System.out.println("child m10");

	}

//	public static void m15() {
//		System.out.println("child m15");
//	}

	public static void main(String[] args) {

		Parent p = new Parent();
		p.m10();
		p.m15();

		Child c = new Child();
		c.m10();
		c.m15();

		Parent p1 = new Child();
		p1.m10();
		// here what we can Understand is we can also call the static method which we
		// bound to class level, that static method also we can call with method
		// reference
		// we can also call like this -> Parent.m15();
		p1.m15();

//	Child c1 = new Parent();

//		Child c1 = (Child) new Parent();
//		c1.m2();
	}

}
