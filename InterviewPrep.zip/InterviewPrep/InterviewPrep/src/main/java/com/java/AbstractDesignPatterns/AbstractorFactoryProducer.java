package com.java.AbstractDesignPatterns;

public class AbstractorFactoryProducer {
	
	public AbstractFactory getAbstractFactory(String value) {
		if(value.equals("Ecnomic")) {
			return new EcnomicCarFactory();
		}
		else if(value.equals("Luxary") || value.equals("premium")) {
			return new LuxaryCarFactory();
		}
		return null;
	}

}
