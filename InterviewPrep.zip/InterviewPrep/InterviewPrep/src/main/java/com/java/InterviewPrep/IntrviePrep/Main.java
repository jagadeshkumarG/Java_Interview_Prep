package com.java.InterviewPrep.IntrviePrep;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Main {

	public static void main(String[] args) {
		
		List<Integer> numList = Arrays.asList(1, 2, 2, 3, 4, 5, 5, 6, 7, 8);

//		numList.stream()
//		.filter(n -> n%2 != 0).sorted(Comparator.naturalOrder())
//			.average().orElse(null);
		Set<Integer> set = new HashSet<>();
		Set<Integer> duplicateSet = numList.stream().filter(n -> !set.add(n))
		.collect(Collectors.toSet());
		
		System.out.println("duplicateSet :" + duplicateSet);
		
	}

}
