package com.java.Interview.PrepSeries;

import java.util.Arrays;

public class KthSmallestElementInArray {

	public static void main(String[] args) {

		int[] arr = { 4, 2, 7, 1, 3, 6, 9, 8, 5 };

		int k = 3; // Find the 3rd smallest element

		int orElse = Arrays.stream(arr).sorted().skip(k - 1).findFirst().orElse(-1);
		int Kthsmallest = Arrays.stream(arr).sorted().skip(k - 1).findFirst().getAsInt();

		System.out.println("orElse :" + orElse);

	}

}
