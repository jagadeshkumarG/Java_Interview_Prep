package com.java.Interview.ImTejaYTTelugu.Epam;

class Address {
	String city;

	Address(String city) {
		this.city = city;
	}
}

public class Cloning implements Cloneable {

	String name;
	Address address;

	Cloning(String name, Address address) {
		this.name = name;
		this.address = address;
	}

	protected Object clone() throws CloneNotSupportedException {

		Cloning cloned = (Cloning) super.clone(); // Shallow cloning
		cloned.address = new Address(this.address.city);  //Deep cloning
		return cloned;

	}

}
