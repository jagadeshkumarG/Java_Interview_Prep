package com.java.AbstractDesignPatterns;

public class EcnomicCar1 implements Car{

	@Override
	public int getTopSpeed() {
		return 100;
	}

}
