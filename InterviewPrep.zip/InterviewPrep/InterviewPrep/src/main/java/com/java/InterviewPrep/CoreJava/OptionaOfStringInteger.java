package com.java.InterviewPrep.CoreJava;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class OptionaOfStringInteger {

	public static void main(String[] args) {
		
		// Here I want to return Optional<String> with any of the use case

		List<String> fruitList = Arrays.asList("Apple", "Banana", "Kiwi", "Grapes", "DragonFruit");

		Optional<String> string = fruitList.stream().map(String::toUpperCase).filter(str -> str.startsWith("A")).findFirst();
		
		Optional<String> max = fruitList.stream().max((s1, s2) -> Integer.compare(s1.length(), s2.length()));
		
		// Here I want to return Optional<Integer> with any of the use case
		
		List<Integer> intList = List.of(1, 3 , 4, 8, 5, -1, -9, -6, 6, 8, 10);
		
		Optional<Integer> filter = intList.stream().distinct().filter(n -> n%2 ==0).max((s1, s2) -> Integer.compare(s1.compareTo(s2), s2));
//				filter.ifPresent();

	}

}
