package com.java.InterviewPrep.CoreJava;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

class Employee {
	private int id;
	private String name;
	private int salary;

	public Employee(int id, String name, int age) {
		this.id = id;
		this.name = name;
		this.salary = age;
	}

	// Getters for the fields
	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public int getSalary() {
		return salary;
	}

	@Override
	public String toString() {
		return "Employee{id=" + id + ", name='" + name + "', salary=" + salary + "}";
	}
}

//public class EmployeeStreamExample {
//    public static void main(String[] args) {
//        List<Employee> employeeList = Arrays.asList(
//            new Employee(1, "Alice", 30),
//            new Employee(2, "Bob", 25),
//            new Employee(3, "Charlie", 35),
//            new Employee(4, "David", 40)
//        );
//
//        // Using Java 8 Streams to iterate over the List of Employee objects
//        employeeList.stream()
//                    .forEach(employee -> System.out.println(employee));
//    }
//}

public class EmployeeStreamExample {
	public static void main(String[] args) {
		// Creating a HashMap to store Employee objects with ID as the key
		Map<Integer, Employee> employeeMap = new HashMap<>();

		employeeMap.put(1, new Employee(1, "Alice", 300000));
		employeeMap.put(2, new Employee(2, "Bob", 250000));
		employeeMap.put(3, new Employee(3, "Charlie", 350000));
		employeeMap.put(4, new Employee(4, "David", 400000));

		// Using Java 8 Streams to iterate over the employeeMap and print details
//		employeeMap.entrySet().stream().forEach(entry -> {
//			Integer id = entry.getKey();
//			Employee employee = entry.getValue();
//			System.out.println("ID: " + id + ", " + employee);
//		});
//
//		// Filter employees older than 30 and print their details
//		System.out.println("\nEmployees older than 30:");
//		employeeMap.entrySet().stream().filter(entry -> entry.getValue().getAge() > 30).forEach(entry -> {
//			Integer id = entry.getKey();
//			Employee employee = entry.getValue();
//			System.out.println("ID: " + id + ", " + employee);
//		});

		List<Employee> employeeList = Arrays.asList(new Employee(1, "Alice", 30), new Employee(2, "Bob", 25),
				new Employee(3, "Charlie", 35), new Employee(4, "David", 40));

		 //Using Java 8 Streams to iterate over the List of Employee objects
		employeeList.stream().forEach(employee -> System.out.println(employee));
//		employeeList.stream().filter(entry -> entry.getAge() > 30).forEach(entry -> System.out.println(entry));
//		employeeList.stream().sorted((e1, e2) -> Integer.compare(e1.getAge(), e2.getAge())).forEach(emp -> System.out.println(emp));
		employeeList.stream().sorted().forEach(System.out::println);
//		double averageAge = employeeList.stream().mapToInt(Employee::getAge).average().orElse(0.0);
//		System.out.println("Average Age: " + averageAge);
		List<String> empList = employeeList.stream().map(Employee::getName).collect(Collectors.toList());
		System.out.println("Average Age: " + empList);
		Map<Integer, Employee> collectToMap = employeeList.stream()
				.collect(Collectors.toMap(Employee::getId, emp -> emp));
		System.out.println("Collecting To Map :" + collectToMap);
//		Employee oldestEmployee = employeeList.stream().max((e1, e2) -> Integer.compare(e1.getAge(), e2.getAge())).orElse(null);
//		System.out.println("Oldest Employee: " + oldestEmployee);

		boolean removeIf = employeeMap.entrySet().removeIf(emp -> emp.getValue().getSalary() < 300000);

		System.out.println("removeIf : " + removeIf);

//		employeeMap.entrySet().stream().map(Employee::getSalary).sorted(Comparator.reverseOrder()).

		Optional<Integer> secondHighestSalary = employeeList.stream().map(Employee::getSalary).distinct()
				.sorted(Comparator.reverseOrder()).skip(1).findFirst();

		System.out.println(secondHighestSalary);

		secondHighestSalary.ifPresentOrElse(salary -> System.out.println("Second Highest Salary: " + salary),
				() -> System.out.println("NOT_FOUND"));

	}
}
