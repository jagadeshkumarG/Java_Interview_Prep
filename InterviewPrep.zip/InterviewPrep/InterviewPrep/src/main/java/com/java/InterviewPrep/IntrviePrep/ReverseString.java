package com.java.InterviewPrep.IntrviePrep;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class ReverseString {
    public static void main(String[] args) {
        String original = "Hello, World!";
        String reversed = new StringBuilder(original)
                .chars()
                .mapToObj(c -> (char) c)
                .sorted((a, b) -> -1) // reverse order
                .map(String::valueOf)
                .collect(Collectors.joining());

        System.out.println(reversed);

//        Arrays.stream(original.split("")).chars()
//                .mapToObj(c -> (char) c)
//                .sorted((a, b) -> -1) // reverse order
//                .map(String::valueOf)
//                .collect(Collectors.joining());

        String reversed2 = new StringBuilder(original).reverse().toString();
        System.out.println("reversed2: " + reversed2);

        String reversed3 = IntStream.rangeClosed(1, original.length())
                .mapToObj(i -> original.charAt(original.length() - i))
                .map(String::valueOf)
                .collect(Collectors.joining());

        System.out.println(reversed3);
        
        Map<String, Long> charCount = Arrays.stream(original.split(""))
        .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
        
        System.out.println("charCount : " + charCount);
        
        String [] words = original.split(" ");        
        List<String> reversed5 = Arrays.stream(words)
        		.map((word) -> new StringBuffer(word).reverse().toString())
        		.collect(Collectors.toList());
        System.out.println("reversed5: " + reversed5);
        
    }
}
