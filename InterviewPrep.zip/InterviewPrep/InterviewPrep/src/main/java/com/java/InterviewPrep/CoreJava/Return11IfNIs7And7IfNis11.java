package com.java.InterviewPrep.CoreJava;

public class Return11IfNIs7And7IfNis11 {

	private static int testData(int n) {
		return 7 + 11 - n;

	}

	public static void main(String[] args) {

		System.out.println("Input is 7 -> Returning :: " + testData(7));
		System.out.println("Input is 11 -> Returning :: " + testData(11));
	}

}
