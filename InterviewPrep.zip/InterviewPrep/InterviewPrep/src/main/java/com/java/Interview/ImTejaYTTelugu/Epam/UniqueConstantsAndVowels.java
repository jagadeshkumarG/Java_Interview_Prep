package com.java.Interview.ImTejaYTTelugu.Epam;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class UniqueConstantsAndVowels {

	public static void main(String[] args) {

		String input = "The Java Programming";
		String lower = input.toLowerCase();

		Set<Character> vowelSet = new HashSet<>(Arrays.asList('a', 'e', 'i', 'o', 'u'));

		List<Character> letters = lower.chars().mapToObj(c -> (char) c).filter(Character::isLetter)
				.collect(Collectors.toList());

		Map<Boolean, List<Character>> partitionedList = letters.stream()
				.collect(Collectors.partitioningBy(vowelSet::contains));

		Set<Character> vowels = new LinkedHashSet<>(partitionedList.get(true));
		Set<Character> constants = new LinkedHashSet<>(partitionedList.get(false));

//		vowels.forEach(System.out::println);
//		constants.forEach(System.out::println);

		StringBuilder sb = new StringBuilder();
		vowels.forEach(sb::append);
		constants.forEach(sb::append);

		System.out.println("Result : " + sb);
	}

}
