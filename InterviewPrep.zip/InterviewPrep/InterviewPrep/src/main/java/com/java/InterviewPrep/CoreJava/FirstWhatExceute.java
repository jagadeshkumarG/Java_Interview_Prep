package com.java.InterviewPrep.CoreJava;

public class FirstWhatExceute {
	
	static {
		System.out.println("First static Block is Executed");
	}
	
	public void method(Object o) {
		System.out.println("Object method");
	}
	
	
	public void method(String s) {
		System.out.println("String method");
	}

	public static void main(String[] args) {
		
		System.out.println("First Main is method Executed");
		
		//It will go to string y because it will go to the most LOWEST acceptable NULL value that is STRING
		// OBJECT is most HIGHEST acceptable NULL value
		new FirstWhatExceute().method(null);
		
		Integer a = 128;
		Integer b = 128;
		System.out.println(a == b);
		// == -> Reference 
		// Int range between -128 to 127
		
		try {
			throw new RuntimeException("Exception in try");
		} finally {
			System.out.println("finally block executed");
		}
		
		///final int x;
		//x = 10;
		//System.out.println(x);
	}

}
