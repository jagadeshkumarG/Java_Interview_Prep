package com.java.InterviewPrep.IntrviePrep;

import java.util.Arrays;
import java.util.Optional;

import com.java.InterviewPrep.Data.Student;

public class OptionalDemo {

	public static void main(String[] args) {
		
		String str = null;
			
		Optional<String> optional = Optional.ofNullable(str);
		
		if(optional.isPresent()) {
			System.out.println("Value :" + str);
		} else {
			String value = optional.orElse("DefaultValue");
			System.out.println("Value :" + value);
		}
		
		Optional<String> opt = Optional.of("Hello");
		Optional<String> opt1 = Optional.ofNullable(null);  // Returns an empty Optional

		System.out.println("opt1 :" + opt1);
		
		Optional<String> opt2 = Optional.ofNullable(null);
		String result = opt2.orElseGet(() -> "Generated Default Value");


		
		Student student = new Student("Jagha", 10, 10, null, Arrays.asList("Acting", "Dance", "Heroism"));
	}

}
