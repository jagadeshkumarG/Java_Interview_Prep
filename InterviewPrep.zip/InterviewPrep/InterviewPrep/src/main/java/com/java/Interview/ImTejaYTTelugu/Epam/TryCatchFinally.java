package com.java.Interview.ImTejaYTTelugu.Epam;

public class TryCatchFinally {

//	public static int test() {
//		try {
//			System.out.println("Try Block executed");
//			return 2;
//		} finally {
//			System.out.println("Finally Block Executed");
//			return 4;
//		}
//	}

	public static int test2() {
		int x = 0;
		try {
//			System.exit(1); here finally will not execute if we give system.exit
			x = 1;
			return x;
		} finally {
			x = 2;
			return x;
			// as is in finally it will execute orelse if return in try block ot
			// will execute
		}
	}

	public static void test() {
		try {
			// Parent try block
			try {
				// child try block
				int b = 0;
				int c = 1 / b;
			} catch (ArithmeticException ex) {
				System.out.println("caught ArithmeticException in child try block");
			}
			int[] a = new int[0];
			System.out.println(a[1]); // throws ArrayIndexOutBoundsException
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("caught ArrayIndexOutBoundsException in Parent try block");
		}
	}

	public static void main(String[] args) {
		System.out.println("returned value is : " + test2());
		test();

	}

}
