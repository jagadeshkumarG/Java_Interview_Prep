package com.java.InterviewPrep.IntrviePrep;

public class javaTechieeJava834Min {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
