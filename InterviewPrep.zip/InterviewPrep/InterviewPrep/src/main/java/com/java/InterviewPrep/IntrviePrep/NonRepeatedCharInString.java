package com.java.InterviewPrep.IntrviePrep;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.stream.Collectors;

public class NonRepeatedCharInString {

	public static void main(String[] args) {

		String inputString = "Java Learing For Interview Prep";

		Map<String, Long> charCountMap = Arrays.stream(inputString.split(""))
				.collect(Collectors.groupingBy(Function.identity(), LinkedHashMap::new, Collectors.counting()));
		System.out.println(charCountMap);
		
		   List<Entry<String, Long>> nonRepeatedCharToList = charCountMap.entrySet().stream().filter(entry -> entry.getValue() == 1)
				.collect(Collectors.toList());
		   System.out.println("nonRepeatedCharToList : " + nonRepeatedCharToList);

		String nonRepeatedChar = charCountMap.entrySet().stream().filter(entry -> entry.getValue() == 1)
				.map(entry -> entry.getKey()).findFirst().get();
		System.out.println("nonRepeatedChar : " + nonRepeatedChar);

		Character nonRepeatedChar2 = inputString.chars().mapToObj(c -> (char) c)
				.filter(ch -> inputString.indexOf(ch) == inputString.lastIndexOf(ch)).findFirst().orElse(null);
		System.out.println("nonRepeatedChar2 : " + nonRepeatedChar2);
	}
}
