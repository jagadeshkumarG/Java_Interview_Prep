package com.java.InterviewPrep.CoreJava;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import lombok.Data;

@Data
class Product {
    String name;
    double price;

    Product(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
    public String toString() {
        return name + ": " + price;
    }
}

public class CustomSortingRule {
	
	    public static void main(String[] args) {
	        List<Product> products = Arrays.asList(
	                new Product("Product1", 60),
	                new Product("Product2", 30),
	                new Product("Product3", 50),
	                new Product("Product4", 70)
	        );
	        
//	        Sort products by price greater than 50 in ascending order, 
//	        and those with a price less than or equal to 50 in descending order. 
//	        Sort by name if prices are the same.
	        
//	        products.stream().filter(pr -> pr>50==0)
//	        	.sorted()
//	        	.filter(pr -> pr<=50==0)
//	        	.sorted(Comparator.reverseOrder()).forEach(System.out::println);
	        
	        List<Product> sortedProducts = products.stream()
	                .sorted(Comparator.comparingDouble((Product p) -> p.price)
	                        .thenComparing(Product::getName))
	                .sorted(Comparator.comparingDouble((Product p) -> p.price > 50 ? p.price : -p.price))
	                .collect(Collectors.toList());

	        sortedProducts.forEach(System.out::println);
	        	

	}

}
