package com.java.intervieww.LlyodsIntExp;

public class Customer {

	public static void main(String[] args) {

		StringProcessing toUpperCase = s -> s.toUpperCase();

		String input = "llyods interview exp by sravan frnd";

		String output = toUpperCase.process(input);
		
		System.out.println("output : " + output);

	}

}
