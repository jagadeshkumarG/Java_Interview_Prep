package com.java.InterviewPrep.CoreJava;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MovingZerosToTheRight {

	public static void main(String[] args) {

		List<Integer> intList = List.of(0, -1, -2, -3, 0, 1, 0, 2, 3, 4, 0, 0);

		List<Integer> zerosToRight = Stream
				.concat(intList.stream().filter(n -> n != 0), intList.stream().filter(n -> n == 0))
				.collect(Collectors.toList());
		System.out.println(zerosToRight);

		// zerosToRight.forEach(System.out::println);

		List<Integer> zerosToLeft = Stream
				.concat(intList.stream().filter(n -> n == 0), intList.stream().filter(n -> n != 0))
				.collect(Collectors.toList());

		System.out.println(zerosToLeft);
	}

}
