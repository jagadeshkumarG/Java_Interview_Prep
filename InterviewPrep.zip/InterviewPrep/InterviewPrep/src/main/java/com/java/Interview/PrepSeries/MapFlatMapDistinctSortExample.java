package com.java.Interview.PrepSeries;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.stream.Collectors;

public class MapFlatMapDistinctSortExample {

	public static void main(String[] args) {

		List<List<Integer>> nestedLists = Arrays.asList(Arrays.asList(1, 2, 3), Arrays.asList(3, 4, 5),
				Arrays.asList(5, 6, 7));

		List<Integer> nestedListResult = nestedLists.stream().flatMap(List::stream).sorted(Comparator.reverseOrder())
				.distinct().map(num -> num * num).collect(Collectors.toList());

		System.out.println("NestedListResult: " + nestedListResult);

		List<Integer> numbers = Arrays.asList(1, 2, 2, 3, 4, 4, 5);

//		Map<Integer, Long> singleAppearence = numbers.stream()
//				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
//		
//		List<Integer> collect = singleAppearence.entrySet().stream().filter(e -> e.getValue()=1).map(n -> n.getKey()).collect(Collectors.toList());
//
//		System.out.println("singleAppearence : " + singleAppearence);
//		System.out.println("collect : " + collect);

		List<Integer> singleAppearence = numbers.stream().filter(num -> Collections.frequency(numbers, num) == 1)
				.collect(Collectors.toList());
		System.out.println("SingleAppearence : " + singleAppearence);

		String[] strings = { "apple", "banana", "cherry", "watermelon" };

		String maxString = Arrays.stream(strings).max(Comparator.comparing(String::length)).orElse("No Strings found");
		System.out.println("MaxString :" + maxString);

	}

}
