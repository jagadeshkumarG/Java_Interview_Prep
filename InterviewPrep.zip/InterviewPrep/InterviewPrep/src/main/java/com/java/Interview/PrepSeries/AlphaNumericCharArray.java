package com.java.Interview.PrepSeries;

import java.util.Arrays;

public class AlphaNumericCharArray {

	public static void main(String[] args) {

		String input = "a1b23d4e5f6g7h8i9j0";

		char[] arr = input.toCharArray();

		int[] array = new String(arr).chars().filter(Character::isDigit).map(Character::getNumericValue).toArray();
		
//		String string = new String(arr).chars().filter(Character::isLetter).map(Character::getDirectionality).toString();

		System.out.println("array :" + Arrays.toString(array));
//		System.out.println("String :" + string);

	}

}
