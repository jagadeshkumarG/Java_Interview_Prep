package com.java.Interview.ImTejaYTTelugu.Epam;

public class Parent {
	
	public static void m15() {
		System.out.println("parent m15");
	}

	public void m1() {
		System.out.println("parent m1");

	}

	public void m2() {
		System.out.println("parent m2");

	}

	public void m3() {
		System.out.println("parent m3");

	}

	public void m4() {
		System.out.println("parent m4");

	}

	public void m5() {
		System.out.println("parent m5");

	}

	public void m6() {
		System.out.println("parent m6");

	}

	public void m7() {
		System.out.println("parent m7");

	}

	public void m8() {
		System.out.println("parent m8");

	}

	public void m9() {
		System.out.println("parent m9");

	}

	public void m10() {
		System.out.println("parent m10");

	}

}
