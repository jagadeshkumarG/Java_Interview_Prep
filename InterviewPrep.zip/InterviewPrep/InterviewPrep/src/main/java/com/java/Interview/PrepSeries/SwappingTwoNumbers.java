package com.java.Interview.PrepSeries;

public class SwappingTwoNumbers {

	public static void main(String[] args) {

		int a = 5;
		int b = 3;

		// Swap using addition and subtraction
		a = a + b;
		b = a - b;
		a = a - b;

		System.out.println("a : " + a);
		System.out.println("b : " + b);
	}

}
