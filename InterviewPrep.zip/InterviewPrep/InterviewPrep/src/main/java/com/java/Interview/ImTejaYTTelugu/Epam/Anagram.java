package com.java.Interview.ImTejaYTTelugu.Epam;

import java.util.stream.Collectors;

public class Anagram {

	public static void main(String[] args) {

		String str1 = "listen";
		String str2 = "silent";

		boolean isAnagram = str1.length() == str2.length() && sortString(str1).equals(sortString(str2));

		System.out.println("Are Anagrams: " + isAnagram);
	}

	private static String sortString(String input) {
		return input.chars().sorted().mapToObj(c -> String.valueOf((char) c)).collect(Collectors.joining());
	}

}
