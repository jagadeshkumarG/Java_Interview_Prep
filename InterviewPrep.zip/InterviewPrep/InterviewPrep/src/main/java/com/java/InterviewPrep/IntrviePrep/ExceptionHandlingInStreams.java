package com.java.InterviewPrep.IntrviePrep;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ExceptionHandlingInStreams {

	public static void main(String[] args) {
			List<String> strList = Arrays.asList("44", "124", "234");
			
			strList.stream().map(Integer::parseInt).forEach(System.out::println);
			
			strList.forEach(ExceptionHandlingInStreams::printstats);
			
			List<Integer> collectStrList = strList.stream().map(Integer::parseInt).collect(Collectors.toList());
			
			System.out.println(collectStrList);
		
	}
	
	public static void printstats(String s) {
		try {
		System.out.println(Integer.parseInt(s));
		
		} catch(Exception e) {
			System.out.println("exception : " + e.getMessage());
		}
	}

}
