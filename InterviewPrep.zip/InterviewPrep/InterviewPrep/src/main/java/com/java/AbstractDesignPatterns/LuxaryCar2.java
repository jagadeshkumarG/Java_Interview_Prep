package com.java.AbstractDesignPatterns;

public class LuxaryCar2 implements Car{

	@Override
	public int getTopSpeed() {
		return 300;
	}

	

}
