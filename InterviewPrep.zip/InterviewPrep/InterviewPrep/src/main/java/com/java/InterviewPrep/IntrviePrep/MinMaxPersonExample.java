package com.java.InterviewPrep.IntrviePrep;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

//		List<Integer> intList = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
//		
//		Integer maxValue = intList.stream().max(Comparator.naturalOrder()).get();
//		
//		Integer minValue = intList.stream().max(Integer::compareTo).get();

class Person {
	String name;
	int age;

	Person(String name, int age) {
		this.name = name;
		this.age = age;
	}

	public int getAge() {
		return age;
	}

	@Override
	public String toString() {
		return name + " (" + age + ")";
	}
}

public class MinMaxPersonExample {
	public static void main(String[] args) {
		List<Person> people = Arrays.asList(new Person("Alice", 30), new Person("Bob", 22), new Person("Charlie", 25),
				new Person("Diana", 35));

		// Finding youngest (min age)
		Optional<Person> youngest = people.stream().min((p1, p2) -> Integer.compare(p1.getAge(), p2.getAge()));

		// Finding oldest (max age)
		Optional<Person> oldest = people.stream().max((p1, p2) -> Integer.compare(p1.getAge(), p2.getAge()));

		youngest.ifPresent(person -> System.out.println("Youngest: " + person));
		oldest.ifPresent(person -> System.out.println("Oldest: " + person));

	}

}
