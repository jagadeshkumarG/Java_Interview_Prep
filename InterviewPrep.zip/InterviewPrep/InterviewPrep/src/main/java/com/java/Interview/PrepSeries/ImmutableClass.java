package com.java.Interview.PrepSeries;

public final class ImmutableClass {
	// Making all fields as private
	private final String name;
	private final int age;
	private final double salary;

	// adding constructor

	public ImmutableClass(String name, int age, double salary) {
		this.age = age;
		this.name = name;
		this.salary = salary;
	}

	// adding only getter methods not setter methods

	public String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}

	public double getSalary() {
		return salary;
	}

}
