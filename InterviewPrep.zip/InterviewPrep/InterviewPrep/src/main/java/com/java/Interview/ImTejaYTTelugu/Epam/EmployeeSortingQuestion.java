package com.java.Interview.ImTejaYTTelugu.Epam;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

class Employee {
	private int id;
	private String name;
	private String department;
	private String gender;
	private double salary;

	// Constructor
	public Employee(int id, String name, String department, String gender, double salary) {
		this.id = id;
		this.name = name;
		this.department = department;
		this.gender = gender;
		this.salary = salary;
	}

	// Getters and Setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDepartment() {
		return department;
	}

	public String getGender() {
		return gender;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee{id=" + id + ", name='" + name + "', department='" + department + "', salary=" + salary + "}";
	}
}

public class EmployeeSortingQuestion {

	public static void main(String[] args) {
		
		//Ways of Obj creation
//		Employee emp1 = new Employee(0, null, null, null, 0);
//		Employee emp2 = (Employee) Class.forName("").getDeclaredConstructor().newInstance(null);
//		Constructor<Employee> constructor = Employee.class.getConstructor();
//		Employee emp3 = constructor.newInstance();
//		Employee emp4 = (Employee) emp4.clone();

		List<Employee> employees = Arrays.asList(new Employee(101, "John Doe", "HR", "Male", 50000.00),
				new Employee(102, "Alice", "IT", "Female", 60000.00),
				new Employee(103, "Sam Brown", "Finance", "Male", 55000.00),
				new Employee(104, "Jane", "HR", "Female", 62000.00),
				new Employee(105, "David Wilson", "Sales", "Male", 48000.00));

		// second highest salary
		Optional<Double> secondHighestSalary = employees.stream().mapToDouble(Employee::getSalary).boxed()
				.sorted((a, b) -> Double.compare(b, a)).skip(1).findFirst();
		System.out.println("secondHighestSalary : " + secondHighestSalary);

//		var temp = employees.stream().mapToDouble(Employee::getSalary).average().orElse(0);
//		System.out.println("temp : " + temp);

		double averageSalary = employees.stream().mapToDouble(Employee::getSalary).average().orElse(0);
		System.out.println("averageSalary : " + averageSalary);

		List<String> salaryaAboveAverageSalary = employees.stream().filter(emp -> emp.getSalary() > averageSalary)
				.map(Employee::getName).collect(Collectors.toList());

		System.out.println("SalaryaAboveAverageSalary : " + salaryaAboveAverageSalary);

		Map<String, List<Employee>> employeesByDepartment = employees.stream()
				.collect(Collectors.groupingBy(Employee::getDepartment));
		System.out.println("employeesByDepartment : " + employeesByDepartment);

		Map<String, Long> employeesByDepartmentCount = employees.stream()
				.collect(Collectors.groupingBy(Employee::getDepartment, Collectors.counting()));
		System.out.println("employeesByDepartmentCount : " + employeesByDepartmentCount);

		List<Employee> nameAfterSalary = employees.stream()
				.sorted(Comparator.comparing(Employee::getName).thenComparingDouble(Employee::getSalary))
				.collect(Collectors.toList());
		System.out.println("nameAfterSalary : " + nameAfterSalary);

		// printing List of Emps to Map

		Map<Integer, String> listtoMap = employees.stream()
				.collect(Collectors.toMap(Employee::getId, Employee::getName));
		System.out.println("ListtoMap : " + listtoMap);

		// Highest salary by each department

		Map<String, Optional<Employee>> higestSalaryDeptWise = employees.stream().collect(Collectors.groupingBy(
				Employee::getDepartment, Collectors.maxBy(Comparator.comparingDouble(Employee::getSalary))));

		System.out.println("higestSalaryDeptWise :" + higestSalaryDeptWise);

		List<Employee> sortEmpBySal = employees.stream().sorted(Comparator.comparingDouble(Employee::getSalary))
				.collect(Collectors.toList());
		System.out.println("sortEmpBySal : " + sortEmpBySal);

	}

}
