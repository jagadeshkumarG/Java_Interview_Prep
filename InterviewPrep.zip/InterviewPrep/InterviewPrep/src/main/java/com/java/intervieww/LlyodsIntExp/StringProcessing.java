package com.java.intervieww.LlyodsIntExp;
@FunctionalInterface
public interface StringProcessing {
	
	String process(String input);

}
