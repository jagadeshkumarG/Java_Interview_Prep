package com.java.InterviewPrep.CoreJava;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Strings {

	public static void main(String[] args) {

		List<String> strings = Arrays.asList("apple", "banana", "cherry", "date");

		Map<String, Long> stringsCount = strings.stream()
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		System.out.println("stringsCount : " + stringsCount);
		Map<String, Long> stringsCount2 = strings.stream()
				.collect(Collectors.groupingBy(w -> w, Collectors.counting()));
		System.out.println("stringsCount2 : " + stringsCount2);

		String makingIntoSingleSentense = strings.stream().collect(Collectors.joining(" "));
		System.out.println("makingIntoSingleSentense : " + makingIntoSingleSentense);

		String joiningByComma = strings.stream().collect(Collectors.joining(","));
		System.out.println("joiningByComma : " + joiningByComma);

		Map<String, Integer> convertToMapStringInteger = strings.stream()
				.collect(Collectors.toMap(String::toUpperCase, String::length));
		System.out.println("convertToMapStringInteger : " + convertToMapStringInteger);
		Map<String, Integer> convertToMapStringInteger2 = strings.stream()
				.collect(Collectors.toMap(s -> s, String::length));
		System.out.println("convertToMapStringInteger2 : " + convertToMapStringInteger2);

//		String s1 = "Chat";
//		s1.concat("gpt");
//		String s3 = s1.concat(s1);
//		String s2 = s1.concat("gpt");
//
//		System.out.println(s1);
//		System.out.println(s2);
//		System.out.println("s3 : "+ s3);
//		
//		String message = "Hello";

//		IGreeter greeter = (String username) -> {
//			message = "Welcome";
//			System.out.println("Great Day :" + username);
//		}

		String s1 = new String("hello");
		String s2 = new String("hello");
		String s3 = "hello";
		String s4 = "hello";
		String s5 = "Hello";
		System.out.println(s1 == s2); // false ->new String("hello") creates a new object in the heap, even if the
										// content is the same. s1 and s2 point to different objects in memory
		System.out.println(s1 == s3); // false
		System.out.println(s3 == s4); // true
		System.out.println(s4 == s5); // flase

		String a = "jaga";
		a.concat("desj");
		String b = a.concat("desh");
//		a = a.concat("desh"); 
		System.out.println("a : " + a);
		System.out.println("b : " + b);

//		try {
//			System.out.println("A");
//			badMethod();
//			
//			System.out.println("B");
//		} catch (Exception ex) {
//			System.out.println("C");
//		} finally {
//			System.out.println("D");
//		}

	}

	private static void badMethod() {
		throw new Error();

	}

}
