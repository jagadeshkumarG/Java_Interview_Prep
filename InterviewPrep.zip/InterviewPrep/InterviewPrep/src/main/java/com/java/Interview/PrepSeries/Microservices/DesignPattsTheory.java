package com.java.Interview.PrepSeries.Microservices;

public class DesignPattsTheory {

	public static void main(String[] args) {

		/*
		 * 🟣Microservices Top Design Patterns
		 * 
		 * Microservices architecture offers numerous patterns to tackle scalability,
		 * fault tolerance, and data management challenges. Here’s a list of essential
		 * patterns every developer should know:
		 * 
		 * 
		 * 🌐 API Gateway Pattern : A single entry point for all client requests,
		 * routing them to appropriate microservices, handling authentication, logging,
		 * etc.
		 * 
		 * 💾 Database per Service : Each microservice has its own database, ensuring
		 * loose coupling and allowing each service to use the database type that best
		 * suits its needs.
		 * 
		 * 📚 Polyglot Persistence : Using different kinds of databases within the same
		 * architecture, depending on each service’s requirements.
		 * 
		 * 🧭 Service Discovery Pattern : Enables microservices to find and communicate
		 * with each other without hard-coding service locations.
		 * 
		 * 🔌 Circuit Breaker Pattern : Prevents failure in one service from cascading
		 * to others by stopping the calls to a failing service after a certain
		 * threshold.
		 * 
		 * 🔄 Saga Pattern : Manages distributed transactions by breaking them into a
		 * series of smaller transactions, coordinated by events or commands.
		 * 
		 * 🖊️ CQRS (Command Query Responsibility Segregation) Pattern : Segregates read
		 * and write operations into separate models to optimize performance,
		 * scalability, and security.
		 * 
		 * 📜 Event Sourcing Pattern : Instead of storing the current state of data, all
		 * changes (events) are stored, providing a complete audit trail and enabling
		 * state rebuilding by replaying the events.
		 * 
		 * 🚧 Bulkhead Pattern : Isolates elements of an application into pools so that
		 * if one fails, the others continue to function.
		 * 
		 * 🔁 Retry Pattern : Automatically retries a failed operation a predefined
		 * number of times before giving up.
		 * 
		 * 🚨 Fallback Pattern : Provides a default response or behavior when a service
		 * fails or is unavailable.
		 * 
		 * 🔙 Backend for Frontend (BFF) Pattern: Creates separate backend services
		 * tailored to the needs of different client types (e.g., web, mobile).
		 * 
		 * 🎭 Sidecar Pattern : Deploys helper components alongside the main service to
		 * provide cross-cutting concerns like logging, monitoring, or configuration.
		 * 
		 * 🌱 Strangler Fig Pattern : Incrementally replaces parts of a legacy system
		 * with new microservices by creating a facade that intercepts requests and
		 * routes them to either the old system or the new microservices.
		 * 
		 * 🖼️ Micro-frontend Architecture : Extends the principles of microservices to
		 * the frontend, allowing different teams to develop and deploy parts of the UI
		 * independently.
		 * 
		 * These patterns are key to building resilient, scalable, and maintainable
		 * microservices architectures. 🚀
		 */

	}

}
