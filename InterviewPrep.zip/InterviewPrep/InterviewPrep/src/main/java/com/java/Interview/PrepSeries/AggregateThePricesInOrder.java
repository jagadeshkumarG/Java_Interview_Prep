package com.java.Interview.PrepSeries;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class AggregateThePricesInOrder {

	public static void main(String[] args) {

//		List<Orders> orders = Arrays.asList(
//
//				new Orders(Arrays.asList(new Item("Pears", 200.45, 22), new Item("Mangoes", 120.45, 45),
//						new Item("Oranges", 145.67, 22), new Item("Mandarins", 207.45, 89))),
//
//				new Orders(Arrays.asList(new Item("Pears", 200.45, 21), new Item("Mangoes", 120.45, 459),
//						new Item("Oranges", 345.67, 22), new Item("Mandarins", 207.45, 89))));

		List<String> list = Arrays.asList("Banana", null, "Apple", "Mango");
		list.sort(Comparator.nullsFirst(Comparator.naturalOrder()));
//		list.sort(Comparator.nullsLast(Comparator.naturalOrder()));
//		list.sort(Comparator.nullsFirst(Comparator.reverseOrder()));
//		list.sort(Comparator.nullsLast(Comparator.reverseOrder()));
		System.out.println(list);

	}

}
