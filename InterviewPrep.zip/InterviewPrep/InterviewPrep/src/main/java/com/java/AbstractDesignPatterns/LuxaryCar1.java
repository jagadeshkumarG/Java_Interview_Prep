package com.java.AbstractDesignPatterns;

public class LuxaryCar1 implements Car{

	@Override
	public int getTopSpeed() {
		return 250;
	}

}
