package com.java.Interview.ImTejaYTTelugu.Epam;

public class SquaringAndAdding {

	// given an number square each digit and and it = 64 == 6^2 + 4^2 = 52;

	public static int SquareNumbers(int number) {
		
		if (number < 10 || number > 99) {
			throw new IllegalArgumentException("number must be two digit number");
		}

		int tensPlace = number / 10; // 6
		int oncePlace = number % 10; // 4

		int squaretensPlace = tensPlace * tensPlace;
		int squareOncePlace = oncePlace * oncePlace;

		return squaretensPlace + squareOncePlace;
	}

	public static void main(String[] args) {

		int input = 64;
		int result = SquareNumbers(input);

		System.out.println("result : " + result);

	}

}
