package com.java.Interview.PrepSeries;

import java.util.Arrays;
import java.util.List;

public class SumIntegers {

	public static void main(String[] args) {
		List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);

		int sum1 = numbers.stream().mapToInt(Integer::intValue).sum();
		System.out.println("sum1 : " + sum1);

		Integer sumWithReduce = numbers.stream().reduce(0, (a, b) -> a + b);
		System.out.println("sumWithReduce : " + sumWithReduce);
	}

}
