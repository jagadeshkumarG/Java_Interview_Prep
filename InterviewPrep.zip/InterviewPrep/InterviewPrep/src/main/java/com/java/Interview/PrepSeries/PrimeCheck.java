package com.java.Interview.PrepSeries;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class PrimeCheck {

	public static void main(String[] args) {

//		IntStream primeNumbers = IntStream.rangeClosed(1, 100)
//				.filter(n -> n > 1 && IntStream.range(2, (int) Math.sqrt(n)).noneMatch(i -> n % i == 0));

//		primeNumbers.forEach(System.out::println);

		String ogString = "Jagadesh";

		String[] splitString = ogString.split("");

		List<String> reversedString = Arrays.stream(splitString).map((str) -> new StringBuffer(str).reverse().toString())
				.collect(Collectors.toList());
		System.out.println("reversedString : " + reversedString);
		
		/*
		 String [] words = original.split(" ");        
        List<String> reversed5 = Arrays.stream(words)
        		.map((word) -> new StringBuffer(word).reverse().toString())
        		.collect(Collectors.toList());
        System.out.println("reversed5: " + reversed5);
		 */
	}

}
