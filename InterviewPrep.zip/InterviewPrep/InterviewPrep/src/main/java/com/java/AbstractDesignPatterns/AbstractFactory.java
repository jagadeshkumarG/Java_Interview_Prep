package com.java.AbstractDesignPatterns;

public interface AbstractFactory {
	
	public Car getInstance(int price);

}
