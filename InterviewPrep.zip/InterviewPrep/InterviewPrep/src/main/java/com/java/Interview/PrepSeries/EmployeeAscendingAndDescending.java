package com.java.Interview.PrepSeries;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class Employee {
	private int id;
	private String name;
	private String department;
	private String gender;
	private double salary;

	// Constructor
	public Employee(int id, String name, String department, String gender, double salary) {
		this.id = id;
		this.name = name;
		this.department = department;
		this.gender = gender;
		this.salary = salary;
	}

	// Getters and Setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDepartment() {
		return department;
	}
	
	public String getGender() {
		return gender;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee{id=" + id + ", name='" + name + "', department='" + department + "', salary=" + salary + "}";
	}
}

public class EmployeeAscendingAndDescending {

	public static void main(String[] args) {

		Employee emp1 = new Employee(101, "John Doe", "HR", "Male",  50000.00);
		Employee emp2 = new Employee(102, "Jane Smithy", "IT", "FeMale", 60000.00);
		Employee emp3 = new Employee(103, "Sam Brown", "Finance", "Male", 55000.00);
		Employee emp4 = new Employee(104, "Emily Davis", "HR", "FeMale", 62000.00);
		Employee emp5 = new Employee(105, "David Wilson", "Sales", "Male" , 48000.00);

		List<Employee> employees = new ArrayList<>();

		employees.add(emp1);
		employees.add(emp2);
		employees.add(emp3);
		employees.add(emp4);
		employees.add(emp5);

		// printing Employees in ascending

		Stream<Employee> sortedEmp = employees.stream().sorted((e1, e2) -> e1.getName().compareTo(e2.getName()));
		sortedEmp.forEach(System.out::println);

		employees.stream().map(Employee::getName).sorted().forEach(System.out::println);

		System.out.println("-----------------------------");

		employees.stream().map(Employee::getName).sorted(Comparator.reverseOrder()).forEach(System.out::println);
		
		Map<String, Optional<Employee>> highestSalaryByDept = employees.stream()
                .collect(Collectors.groupingBy(Employee::getDepartment, 
                        Collectors.maxBy(Comparator.comparingDouble(Employee::getSalary))));
		highestSalaryByDept.forEach((department, emp) -> {
            emp.ifPresent(e -> System.out.println("Department: " + department +  "Salary: " + e.getSalary()));
        });
		
		System.out.println("-------------Finding Average Salary----------------");
			
		OptionalDouble averageSalary = employees.stream().mapToDouble(Employee::getSalary).average();
		
		if(averageSalary.isPresent()) {
			System.out.println("averageSalary :" + averageSalary);
		} else {
			System.out.println("No employees are available");
			
			double averageSalaryy = employees.stream()
                    .collect(Collectors.averagingDouble(Employee::getSalary));
		}
	}

}
