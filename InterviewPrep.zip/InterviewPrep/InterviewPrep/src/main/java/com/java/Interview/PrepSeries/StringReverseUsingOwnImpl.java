package com.java.Interview.PrepSeries;

import java.util.stream.Collectors;

public class StringReverseUsingOwnImpl {
	
	public static String reverse(String input) {
		return input.chars()
				.mapToObj(c -> (char)c)
				.collect(Collectors.toList())
				.stream()
				.map(String::valueOf)
//				.sorted((a, b) -> b-a)
				.reduce((s1, s2) -> s2 + s1)
				.orElse("");
		
	}

	public static void main(String[] args) {
		String original = "Mandhe idhantha";
		String reversed = reverse(original);
		
		System.out.println("original : " + original);
		System.out.println("reverse : " + reversed);
			
	}

}
