package com.java.InterviewPrep.Interviewssss;

public class CriticalRiver {

	public static void permutationsOfString(String prefix, String end) {

		int n = end.length();
		if (n == 0) {
			System.out.println(prefix);
		} else {
			for (int i = 0; i < n; i++) {
				permutationsOfString(prefix + end.charAt(i), end.substring(0, i) + end.substring(i + 1));
			}
		}

	}

	public static void main(String[] args) {

		String str = "abc";
		permutationsOfString("", str);

		/*
		 * abc, acb, bac bca, cab, cba
		 */

	}

}
