package com.java.Interview.PrepSeries;

public class Sample {

//	null can be assigned to any object reference type in Java. 
//	It is compatible with both Object and String, because String is a subclass of Object
	/*
	 * Java sees that null is ambiguous — it could match either:
	 * 
	 * method(Object o),	method(String s)
	 * 
	 * But Java has a rule:
	 * 
	 * If there are multiple overloaded methods that match, the most specific one is
	 * chosen.
	 * 
	 * In this case: String is a subclass of Object, so:
	 * 
	 * method(String s) is more specific than method(Object o)
	 */

	public static void main(String[] args) {
		method(null);
	}

	public static void method(Object o) {
		System.out.println("object method");
	}
	
//	public static void method(Object o) {
//		System.out.println("an another object method");
//	}

	public static void method(String s) {
		System.out.println("String method");
	}

//	public static void method(Integer i) {
//		System.out.println("Integer method");
//	}

}
