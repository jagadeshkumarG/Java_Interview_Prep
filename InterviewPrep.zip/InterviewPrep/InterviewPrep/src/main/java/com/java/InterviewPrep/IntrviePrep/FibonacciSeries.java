package com.java.InterviewPrep.IntrviePrep;

import java.util.stream.Stream;

public class FibonacciSeries {

	public static void main(String[] args) {

		int n = 10;

		Stream<Integer> map = Stream.iterate(new int[] {0, 1}, f -> new int[] {f[1], f[0] + f[1]}).limit(n)
				.map(f -> f[0]);

		map.forEach(System.out::println);
	}
}
