package com.java.InterviewPrep.CoreJava;

import java.util.List;
import java.util.stream.IntStream;

import com.java.InterviewPrep.Data.Employee;
import com.java.InterviewPrep.Data.EmployeeDataBase;

public class ParallelStreamEgg {

	public static void main(String[] args) {
		
		long stratTime = 0;
		long endTime = 0;
		
//		stratTime = System.currentTimeMillis();
//		IntStream.rangeClosed(1, 100).forEach(System.out::println);
//		endTime = System.currentTimeMillis();
//		System.out.println("Time Taken by normal Stream() :" + (endTime-stratTime));
//		
//		System.out.println("-----------------------------------------------------------------");
//		
//		stratTime = System.currentTimeMillis();
//		IntStream.rangeClosed(1, 100).parallel().forEach(System.out::println);
//		endTime = System.currentTimeMillis();
//		System.out.println("Time Taken by ParalleStream() :" + (endTime-stratTime));
		
		
		IntStream.range(1, 10).forEach(x -> {
			System.out.println("Thread : " + Thread.currentThread().getName()+ " : " + x);
		});
		
		IntStream.range(1, 10).parallel().forEach(x -> {
			System.out.println("Thread : " + Thread.currentThread().getName()+ " : " + x);
		});
		
		List<Employee> employees = EmployeeDataBase.getEmployees();
		
		//employees.stream().map(Employee::getSalary).mapToInt(null)
	}

}
