package com.java.Interview.PrepSeries;

import java.util.Set;

public class ImmutableSetExample {
	public static void main(String[] args) {
		// Creating an immutable set using Set.of() (Java 9+)
		Set<String> immutableSet = Set.of("Apple", "Banana", "Orange");

		// Attempting to modify the set will throw an UnsupportedOperationException
		// immutableSet.add("Grapes"); // Uncommenting this will cause a runtime error

		System.out.println(immutableSet); // Output: [Apple, Banana, Orange]
	}
}
