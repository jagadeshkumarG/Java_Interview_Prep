package com.java.InterviewPrep.Interviewssss;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class DataEcnomyIntvwe {

	public static void main(String[] args) {

		String fileName = "C:\\Users\\ramki\\Downloads\\InterviewPrep\\InterviewPrep\\src\\main\\java\\com\\java\\InterviewPrep\\Interviewssss\\ABC.txt";

//		String str = "Hello World";ss

//		String[] split = str.split("");
//
//		Map<String, Long> collectString = Arrays.stream(split)
//				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
//
//		System.out.println("collectString : " + collectString);
//
//		List<String> wordsCount = collectString.entrySet().stream().filter(w -> w.getValue() == 1).map(n -> n.getKey())
//				.collect(Collectors.toList());
//		System.out.println("wordsCount : " + wordsCount);

		try {
			BufferedReader reader = new BufferedReader(new FileReader(fileName));
			String line;
			int wordCount = 0;

			while ((line = reader.readLine()) != null) {
				String[] words = line.split("\\s+");
				wordCount += words.length;
			}
			reader.close();
			System.out.println("Total no.of words : " + wordCount);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
