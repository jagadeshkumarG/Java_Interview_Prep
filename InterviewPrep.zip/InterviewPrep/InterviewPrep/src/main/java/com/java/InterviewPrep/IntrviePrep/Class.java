package com.java.InterviewPrep.IntrviePrep;

import java.util.Arrays;

public class Class {

	public static void main(String[] args) {

		int[] intArrays = { 5, 6, 9, 3, 1, 2, 4 };

		Arrays.sort(intArrays);
		System.out.println(Arrays.toString(intArrays));

	}

}
