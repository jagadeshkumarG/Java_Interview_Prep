package com.java.InterviewPrep.IntrviePrep;

import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class javaTechieeJava842Min {

	public static void main(String[] args) {

		String stringList = "ilovejavatechie";

		Map<String, Long> countofString = Arrays.stream(stringList.split(""))
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

		System.out.println("countofString : " + countofString);

		List<String> duplicateElements = Arrays.stream(stringList.split(""))
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting())).entrySet().stream()
				.filter(x -> x.getValue() > 1)
				.map(Map.Entry::getKey)
				.collect(Collectors.toList());

		System.out.println("DuplicateElements :" + duplicateElements);

		/** Finding first non-Repetitive element **/

		String firstNonRepeateElement = Arrays.stream(stringList.split(""))
				.collect(Collectors.groupingBy(Function.identity(), LinkedHashMap::new, Collectors.counting()))
				.entrySet().stream().filter(x -> x.getValue() == 1)
				// .skip(1)
				.findFirst().get().getKey();

		System.out.println("firstNonRepeateElement :" + firstNonRepeateElement);

		/** Finding first Repetitive element **/

		String firstRepeateElement = Arrays.stream(stringList.split(""))
				.collect(Collectors.groupingBy(Function.identity(), LinkedHashMap::new, Collectors.counting()))
				.entrySet().stream().filter(x -> x.getValue() > 1).findFirst().get().getKey();

		System.out.println("FirstRepeateElement :" + firstRepeateElement);

		// finding second Highest num in an array
		int[] arr = { 5, 9, 11, 2, 8, 21, 1 };

		Integer secondHigest = Arrays.stream(arr).boxed()
				// .sorted((a, b) -> b-a)
				.sorted(Comparator.reverseOrder()).skip(1).findFirst().get();

		System.out.println("SecondHigest :" + secondHigest);

		List<String> elementStratsWith1 = Arrays.stream(arr).boxed().sorted().map(num -> num + "")
				.filter(str -> str.startsWith("1")).collect(Collectors.toList());

		System.out.println("ElementStratsWith1 :" + elementStratsWith1);

		// Longest String from given array
		String[] stringArr = { "java", "techie", "springboot", "spring", "microservices" };

		String longestStr = Arrays.stream(stringArr)
				.reduce((word1, word2) -> word1.length() > word2.length() ? word1 : word2).get();

		System.out.println("LongestStr :" + longestStr);

		// string.join method

		List<String> strList = Arrays.asList("1", "2", "3", "4", "5");

		String joinStr = String.join("-", strList);

		System.out.println(joinStr);
		
		//skip & limit Example
		
		IntStream.rangeClosed(1, 10).skip(1).limit(8).forEach(System.out::println);

	}

}
