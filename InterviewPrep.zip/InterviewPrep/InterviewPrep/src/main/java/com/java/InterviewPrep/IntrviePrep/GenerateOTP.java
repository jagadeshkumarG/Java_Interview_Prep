package com.java.InterviewPrep.IntrviePrep;

public class GenerateOTP {

	public static void main(String[] args) {
		
//		int randomNo = (int) (Math.random()*9000)+1000;
//		
//		String otp = String.valueOf(randomNo);
//		
//		System.out.println(otp);
		
//		String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
//	    StringBuilder otpBuilder = new StringBuilder(OTP_LENGTH);
//	    for (int i = 0; i < OTP_LENGTH; i++) {
//	        int index = secureRandom.nextInt(chars.length());
//	        otpBuilder.append(chars.charAt(index));
//	    }
//	    return otpBuilder.toString();
		
		int randomnom = (int) (Math.random()*90000)+1000;
		
		String otpp = String.valueOf(randomnom);
		
		System.out.println(otpp);
	}

}
