package com.java.AbstractDesignPatterns;

public interface Car {
	
	public int getTopSpeed();

}
