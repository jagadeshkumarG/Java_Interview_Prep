package com.java.InterviewPrep.Interviewssss;

public class Acolitte {

	public static void main(String[] args) {

		int[] arr = { 1, 1, 2, 2, 2, 3, 5, 5, 5, 5 };

		int tar = 5;

		int index = findFirstOccurance(arr, tar);

		System.out.println(index);

	}
	private static int findFirstOccurance(int[] arr, int tar) {

		int left = 0;
		int right = arr.length - 1;

		int result = -1;
		while (left <= right) {

			int mid = left + (right - left) / 2;

			if (arr[mid] == tar) {
				result = mid;
				right = mid - 1;
			} else if (arr[mid] > tar) {
				right = mid - 1;
			} else {
				left = mid + 1;
			}
		}
		return result;
	}

}
