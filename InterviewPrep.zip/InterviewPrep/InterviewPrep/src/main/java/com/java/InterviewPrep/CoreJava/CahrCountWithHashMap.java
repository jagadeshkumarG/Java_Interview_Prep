package com.java.InterviewPrep.CoreJava;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

public class CahrCountWithHashMap {

	/*
	 * Input: "abracadabra" Output: {a=5, b=2, r=2, c=1, d=1}
	 */

	public static void main(String[] args) {

		String str = "abracadabra";
		String[] split = str.split("");

		Map<Character, Long> charCountMap = str.chars().mapToObj(c -> (char) c)
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

		Map<String, Long> usingArrayStrems = Arrays.stream(split)
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

		usingArrayStrems.entrySet().stream().sorted((entry1, entry2) -> entry2.getValue().compareTo(entry1.getValue()))
				.limit(2).forEach(entry -> System.out.println(entry.getKey() + " -> " + entry.getValue()));

		System.out.println("charCountMap :" + charCountMap);

		System.out.println("usingArrayStrems :" + usingArrayStrems);

		String s = "HappynewYear";

		String[] splitt = s.split("");
//		int len = s.length();

		Arrays.stream(splitt).distinct().forEach(System.out::println);
//		Set<String> uniqueS = Arrays.stream(splitt).collect(Collectors.toSet());
//		System.out.println("uniqueS : " + uniqueS);
		
//		Map<Character, Integer> map = new LinkedHashMap<>();
//		for (int i =0; i< s.length(); i++) {
//			map.put(s.charAt(i), !map.containsKey(s.charAt(i)) ? 1 : map.get(s.charAt(i)) +1);
//		}
////		StringBuffer sb = new StringBuffer("");
//		int charCount =0;
//		for (Map.Entry<Character, Integer> mp : map.EntrySet<>()) {
////			sb.append(mp.getKey() + "");
//			s = s.concat(mp.getKey() + "");
//			charCount++;
//		}
//		if (len == charCount) {
//			return s;
//		}
//		else if (charCount< len) {
//			s = s.substring(0, charCount+1);
//		}

	}

}
