package com.java.Interview.ImTejaYTTelugu.Epam;

class B extends A {
	int x;

	void X() {
		super.X();
		System.out.println("B");
	}

	public static void main(String[] args) {
		A a = new B();
		a.X();
	}
}
