package com.java.InterviewPrep.Interviewssss;

public class SingletonDeloite {
	
	private static SingletonDeloite singletoclass = new SingletonDeloite();

	private SingletonDeloite() {
	}
	
	public static SingletonDeloite getInstance() {
		return singletoclass;	
	}

}
