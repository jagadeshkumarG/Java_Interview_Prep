package com.java.Interview.PrepSeries;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.OptionalDouble;
import java.util.stream.Collectors;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Student {

	private String name;
	private int age;
	private String gender;
	private double gpa;

	private Student(String name, int age, String gender, double gpa) {
		super();
		this.name = name;
		this.age = age;
		this.gender = gender;
		this.gpa = gpa;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public double getGpa() {
		return gpa;
	}

	public void setGpa(double gpa) {
		this.gpa = gpa;
	}

	@Override
	public int hashCode() {
		return Objects.hash(age, gender, gpa, name);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		return age == other.age && Objects.equals(gender, other.gender)
				&& Double.doubleToLongBits(gpa) == Double.doubleToLongBits(other.gpa)
				&& Objects.equals(name, other.name);
	}

	@Override
	public String toString() {
		return "Student [name=" + name + ", age=" + age + ", gender=" + gender + ", gpa=" + gpa + "]";
	}

	public static void main(String[] args) {

		List<Student> students = new ArrayList<>();

		students.add(new Student("John Doe", 20, "Male", 3.75));
		students.add(new Student("Jane Smith", 11, "Female", 4.0));
		students.add(new Student("Aiden Johnson", 9, "Male", 3.45));
		students.add(new Student("Emily Brown", 12, "Female", 3.85));
		students.add(new Student("Chris Lee", 20, "Male", 2.95));
		students.add(new Student("Sophia Clark", 11, "Female", 3.67));
		students.add(new Student("Liam Harris", 9, "Male", 3.50));
		students.add(new Student("Olivia Martinez", 12, "Female", 4.0));
		students.add(new Student("Ethan Wilson", 20, "Male", 3.25));
		students.add(new Student("Isabella Taylor", 11, "Female", 3.8));

		// find average grade of students who are older than 20

		OptionalDouble averageGrade = students.stream().filter(e -> e.getAge() > 10).mapToDouble(Student::getGpa)
				.average();

//		averageGrade.ifPresent(value -> System.out.println("averageGrade : " + averageGrade));

		if (averageGrade.isPresent()) {
			System.out.println("Average GPA of students older than 20: " + averageGrade.getAsDouble());
		} else {
			System.out.println("No students older than 20.");
		}

		// Group students by their gpa

		Map<Double, List<Student>> groupingByGPA = students.stream().collect(Collectors.groupingBy(Student::getGpa));

		System.out.println("groupingByGPA : " + groupingByGPA);

		// Finding student with highest gpa

		Student studentwithLowestGPA = students.stream().sorted(Comparator.comparingDouble(Student::getGpa)).findFirst()
				.get();

		System.out.println("studentwithLowestGPA : " + studentwithLowestGPA);

		Map<Double, List<Student>> gpagroup = students.stream().collect(Collectors.groupingBy(Student::getGpa));

		Optional<Double> maxGPA = gpagroup.keySet().stream().max(Double::compareTo);

		System.out.println("maxGPA : " + maxGPA);

	}

}
