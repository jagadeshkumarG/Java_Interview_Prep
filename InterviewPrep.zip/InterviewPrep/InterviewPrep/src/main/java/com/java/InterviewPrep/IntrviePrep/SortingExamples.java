package com.java.InterviewPrep.IntrviePrep;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

class Peeerson {
	String name;
	int age;

	Peeerson(String name, int age) {
		this.name = name;
		this.age = age;
	}

	@Override
	public String toString() {
		return name + " (" + age + ")";
	}
}

public class SortingExamples {

	public static void main(String[] args) {

		List<Integer> intList = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

		List<Integer> opList = intList.stream().distinct().sorted().collect(Collectors.toList());

		List<Integer> opList2 = intList.stream().sorted((a, b) -> b - a).collect(Collectors.toList());

		List<Integer> opList3 = intList.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList());

		List<Integer> opList4 = intList.stream().sorted(Comparator.naturalOrder()).collect(Collectors.toList());

		System.out.println(opList);

		System.out.println(opList2);

		System.out.println(opList3);

		System.out.println(opList4);

		List<String> lengthList = Arrays.asList("vachu", "Pranu", "Kyathi", "Jagha", "Parvathi", "VaraLakshmi");

		List<String> collectLengthList = lengthList.stream()
				.sorted((s1, s2) -> Integer.compare(s1.length(), s2.length())).collect(Collectors.toList());

		List<String> collectLenghtList2 = lengthList.stream().sorted(Comparator.reverseOrder())
				.collect(Collectors.toList());

		List<String> collectLenghtList3 = lengthList.stream().sorted((s1, s2) -> s2.compareTo(s1)).toList();

		System.out.println("collectLengthList : " + collectLengthList);
		System.out.println(collectLenghtList2);
		System.out.println(collectLenghtList3);

		List<Peeerson> people = Arrays.asList(new Peeerson("Alice", 30), new Peeerson("Bob", 25), new Peeerson("Charlie", 35));

		List<Peeerson> persList = people.stream().sorted(Comparator.comparingInt(per -> per.age))
				.collect(Collectors.toList());

		people.stream().filter(peo -> peo.age > 25).forEach(System.out::println);

		System.out.println(persList);

		/////////////////////////////////////////////////////////////////////////////

		List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9);

		// Sort the list of integers in descending order, but only include even numbers
		// in the final list.

		List<Integer> descAndEvenList = numbers.stream().sorted((a, b) -> b - a).filter(num -> num % 2 == 0)
				.collect(Collectors.toList());

		System.out.println("descAndEvenList: " + descAndEvenList);

		List<String> words = Arrays.asList("apple", "and", "banana", "kiwi", "cherry", "pear");
		//Sort a list of String objects by length, and then alphabetically if the lengths are equal.
		List<String> collect = words.stream().sorted(Comparator.comparingInt(String::length).thenComparing(Comparator.naturalOrder()))
				.collect(Collectors.toList());
		System.out.println(collect);
		
		//Sort the list of String values based on the first character and by length if the first characters are the same.
		List<String> sortedWords = words.stream()
                .sorted(Comparator.comparingInt((String s) -> s.charAt(0))
                        .thenComparingInt(String::length))
                .collect(Collectors.toList());

        System.out.println(sortedWords);

	}

}
