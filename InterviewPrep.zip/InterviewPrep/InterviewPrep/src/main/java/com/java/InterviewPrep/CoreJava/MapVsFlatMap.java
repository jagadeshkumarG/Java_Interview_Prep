package com.java.InterviewPrep.CoreJava;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.java.InterviewPrep.Data.Student;
import com.java.InterviewPrep.Data.StudentDataBase;

public class MapVsFlatMap {

	public static void main(String[] args) {
		
		
		List<Student> studentList = StudentDataBase.getAllStudents();
		
		List<List<String>> mapExmple = studentList.stream().map(stud -> stud.getActivities()).collect(Collectors.toList());
		System.out.println(mapExmple);
		
		List<String> flatMapExmpl = studentList.stream().flatMap(stud -> stud.getActivities().stream()).collect(Collectors.toList());
		System.out.println(flatMapExmpl);
		
//		List<String> flatMapExmple = studentList.stream().flatMap(List::stream).collect(Collectors.toList());
//		System.out.println(flatMapExmple);
		
		List<String> distFlatMapExmpl = studentList.stream().flatMap(stud -> stud.getActivities().stream()).distinct().collect(Collectors.toList());
		System.out.println(distFlatMapExmpl);
		
		List<String> sentences = Arrays.asList(
	            "Java 8 introduces streams",
	            "flatMap is very useful",
	            "Streams make working with collections easier"
	        );
		
		List<String> sentenceSplit = sentences.stream().flatMap(sentence -> Arrays.stream(sentence.split(" "))).collect(Collectors.toList());
		System.out.println(sentenceSplit);
		
		Optional<String> name = Optional.of("John");
		
		Optional<String> flatMapOptional = name.flatMap(n -> Optional.of("Hello, " + n));
		System.out.println(flatMapOptional.orElse(null));
		
		Stream<int[]> arrayStream = Stream.of(
	            new int[] {1, 2, 3},
	            new int[] {4, 5},
	            new int[] {6, 7, 8}
	        );
		
		List<Integer> arraysFlatMap = arrayStream.flatMapToInt(Arrays::stream).boxed().collect(Collectors.toList());
		System.out.println(arraysFlatMap);
		
		List<List<String>> wordLists = Arrays.asList(
	            Arrays.asList("apple", "banana", "cherry"),
	            Arrays.asList("dog", "elephant"),
	            Arrays.asList("fish", "goat", "hen")
	        );
		
		List<String> listOfLists = wordLists.stream().flatMap(List::stream).collect(Collectors.toList());
		System.out.println(listOfLists);
		
		List<Integer> numbers = Arrays.asList(1, 2, 3);
		List<Integer> multiplyingFlatmap = numbers.stream().flatMap(n -> Stream.of(n * 10, n * 100)).collect(Collectors.toList());
		System.out.println(multiplyingFlatmap);
		
		List<Optional<String>> optionals = Arrays.asList(
	            Optional.of("apple"),
	            Optional.empty(),
	            Optional.of("banana")
	        );
		
		List<String> optFlatMap = optionals.stream().flatMap(Optional::stream).collect(Collectors.toList());
		
		Stream<Integer> stream1 = Stream.of(1, 2, 3);
        Stream<Integer> stream2 = Stream.of(4, 5, 6);
        
        List<Integer> combinedFlatMap = Stream.of(stream1, stream2).flatMap(s -> s).collect(Collectors.toList());
	}

}
