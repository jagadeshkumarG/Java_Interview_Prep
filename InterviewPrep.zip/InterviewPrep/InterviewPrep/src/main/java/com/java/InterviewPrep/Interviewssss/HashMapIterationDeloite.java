package com.java.InterviewPrep.Interviewssss;

import java.util.HashMap;

public class HashMapIterationDeloite {

	public static void main(String[] args) {

		HashMap<Integer, String> map = new HashMap<Integer, String>();

		map.put(1, "Jagha");

		map.entrySet().forEach((entry) -> System.out.println(entry.getKey() + " " + entry.getValue()));
		
		map.forEach((key, value) -> {System.out.println("key :" + key + ", value :" + value);});
	}

}
