package com.java.Interview.ImTejaYTTelugu.Epam;

public class A {
	int x;

	void X() {
		System.out.println("A");
	}
}

