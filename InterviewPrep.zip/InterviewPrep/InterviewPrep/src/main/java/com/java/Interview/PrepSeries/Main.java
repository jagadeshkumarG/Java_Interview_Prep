package com.java.Interview.PrepSeries;

public class Main implements Test1, Test2{

	public static void main(String[] args) {

	}

	@Override
	public void display() {
		Test1.super.display();
//		Test2.super.display();
	}

}
