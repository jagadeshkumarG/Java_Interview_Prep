package com.java.Interview.PrepSeries;

import java.util.Arrays;
import java.util.List;

public class VowelPresentInString {
	
//	private static final Set<Character> vowels = Stream.of("a", "e", "i", "o", "u").collect(Collectors.toSet());

	public static void main(String[] args) {

		String vowel = "JavProgramming";

		List<String> vowelList = Arrays.asList("a", "e", "i", "o", "u");

		boolean vowelCheck = vowelList.stream().anyMatch(vowels -> vowel.contains("a") || vowel.contains("e")
				|| vowel.contains("i") || vowel.contains("o") || vowel.contains("u"));

		System.out.println(vowelCheck);
		
		
	}

}
