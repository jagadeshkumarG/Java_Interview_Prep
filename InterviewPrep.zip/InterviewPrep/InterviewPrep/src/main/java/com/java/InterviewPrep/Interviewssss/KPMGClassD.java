package com.java.InterviewPrep.Interviewssss;

public class KPMGClassD{

	static int i=10;
 
	public static void main(String[] args) {


		KPMGClassD d1=new KPMGClassD();

		KPMGClassD d2=new KPMGClassD();

		d1.i=20;

		System.out.println(d1.i); // 20

     	System.out.println(d2.i); // 20

 
 
	}
 
}
