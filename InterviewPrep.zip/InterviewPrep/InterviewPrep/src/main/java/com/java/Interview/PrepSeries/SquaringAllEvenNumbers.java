package com.java.Interview.PrepSeries;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class SquaringAllEvenNumbers {

	public static void main(String[] args) {

		List<Integer> integers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 5);

		List<Integer> squaringAllEvenNumbers = integers.stream().distinct().filter(n -> n % 2 == 0).map(num -> num * num)
				.collect(Collectors.toList());

		integers.stream().distinct().filter(n -> n % 2 == 0)
				.forEach(n -> System.out.println("Number: " + n + ", Square: " + (n * n)));

		System.out.println("squaringAllEvenNumbers :" + squaringAllEvenNumbers);
	}

}
