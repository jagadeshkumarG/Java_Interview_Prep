package com.java.InterviewPrep.IntrviePrep;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
public class aaabbbccToa3b3c2 {

	public static void main(String[] args) {

		String str = "aaabbbccc";
		// aaabbbcc -> Input
		// a3b3c2 > output
//		Map<Character, Integer> map = new HashMap<>();
//		for (int i = 0; i < str.length(); i++) {
//			if (map.containsKey(str.charAt(i))) {
//				map.put(str.charAt(i), map.get(str.charAt(i)) + 1);
//			} else {
//				map.put(str.charAt(i), 1);
//			}
//		}
//		map.forEach((k, v) -> System.out.print(k + "" + v));
		
		

//        String input = "aaabbbcc";
//        String compressed = compressString(input);
//        System.out.println(compressed);  // Output: a3b3c2
//    }
//
//    private static String compressString(String input) {
//        return StringUtils.join(StringUtils.splitByCharacterTypeCamelCase(input)
//                .stream()
//                .map(s -> s.charAt(0) + String.valueOf(s.length()))
//                .collect(Collectors.toList()), "");
		
//    
		
//		String result = compressString(str);
		
//		List<String> chars = Arrays.stream(str.split(""))
//                .collect(Collectors.toList());
//		System.out.println(chars);
		
		String result = str.chars()
                .mapToObj(c -> (char) c)
                .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()))
                .entrySet()
                .stream()
                .map(e -> e.getKey() + "" + e.getValue())
//                .sorted()
                .collect(Collectors.joining());

        System.out.println(result); // Output (unordered): a3b3c2
		
	}
}
