package com.java.InterviewPrep.IntrviePrep;

import java.util.Arrays;
import java.util.function.Function;
import java.util.stream.Collectors;

public class codeWithRoy {

	public static void main(String[] args) {

		String str[] = { "java Ruby struts", "spring java", "spring boot", "spring python" };

		Arrays.stream(str)
		.flatMap(x -> Arrays.asList(x).stream())
		.collect(Collectors.groupingBy(Function.identity(), Collectors.counting())).entrySet()
				.forEach(x -> {
					if (x.getKey().equals("spring")) {
						System.out.println(x.getKey() + "" + x.getValue());
					}
				});
	}
}
