package com.java.InterviewPrep.Interviewssss;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.stream.Collectors;

public class PersistantRound1 {

	public static void main(String[] args) {

		String input = "welcome to java";

		String[] str = input.split("");

		Map<String, Long> charCount = Arrays.stream(str)
				.collect(Collectors.groupingBy(Function.identity(), LinkedHashMap::new, Collectors.counting()));

		List<Entry<String, Long>> NonRepeated = charCount.entrySet().stream().filter(wrd -> wrd.getValue() == 1)
				.collect(Collectors.toList());
		System.out.println(NonRepeated);

	}

}
