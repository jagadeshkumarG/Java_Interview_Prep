package com.java.InterviewPrep.Interviewssss;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.DoubleStream;
import java.util.stream.Stream;

public class TCSI {

	public static void main(String[] args) {
		// 1,5,7,8,433,23,23

		List<Integer> list = Arrays.asList(1, 5, 7, 8, 433, 23, 23);
		
		List<String> list1 = Arrays.asList("1", "2", "3");
		Stream<Integer> intStream = list1.stream()
			    .map(s -> Integer.parseInt(s));
		System.out.println("intStream : " + intStream);

		List<Integer> descList = list.stream().sorted(Comparator.reverseOrder()).distinct()
				.collect(Collectors.toList());
		System.out.println("descList : " + descList);

		List<Integer> listStartsWith2 = list.stream().filter(n -> String.valueOf(n).startsWith("2"))
				.collect(Collectors.toList());
		System.out.println("listStartsWith2 : " + listStartsWith2);

		String str = "java interview";

		String[] split = str.split("");

		Map<String, Long> collectstr = Arrays.stream(split)
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		collectstr.entrySet().stream().filter(a -> a.getValue() > 1)
				.forEach(a -> System.out.println(a.getKey() + " - " + a.getValue()));
		
		List<String> list2 = Arrays.asList("1.5", "2.5", "3.0");

		DoubleStream doubleStream = list2.stream()
		    .mapToDouble(s -> Double.parseDouble(s));
		System.out.println("doubleStream : " + doubleStream);

		double avg = doubleStream.average().getAsDouble();
		System.out.println("avg : " + avg);

	}

}
