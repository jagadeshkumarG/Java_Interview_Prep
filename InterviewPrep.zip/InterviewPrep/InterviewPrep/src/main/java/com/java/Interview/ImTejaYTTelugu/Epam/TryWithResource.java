package com.java.Interview.ImTejaYTTelugu.Epam;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class TryWithResource {

	public static void main(String[] args) {

		try {
			BufferedReader reader = new BufferedReader(new FileReader(""));
			String line;
			if ((line = reader.readLine()) != null)
				System.out.println(line);
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		// try without resources
		BufferedReader reader1 = null;
		try {
			reader1 = new BufferedReader(new FileReader(""));
			String line1;
			if ((line1 = reader1.readLine()) != null)
				System.out.println(line1);
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			try {
				reader1.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

}
