package com.java.InterviewPrep.IntrviePrep;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class FindingLastElement {

    public static void main(String[] args) {

        List<String> arrayList = Arrays.asList("One", "Two", "Three", "Four", "Five", "Six");

        arrayList.stream().skip(arrayList.size() -1).forEach(System.out::println);
//        System.out.println("------------------------------");
//        arrayList.stream().sorted(Comparator.reverseOrder()).forEach(System.out::println);
//
//        //System.out.println(stringList);
    }
}
