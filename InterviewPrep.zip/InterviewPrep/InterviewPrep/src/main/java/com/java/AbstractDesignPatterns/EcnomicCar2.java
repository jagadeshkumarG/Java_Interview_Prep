package com.java.AbstractDesignPatterns;

public class EcnomicCar2 implements Car{

	@Override
	public int getTopSpeed() {
		return 150;
	}

}
