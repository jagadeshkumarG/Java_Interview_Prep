package com.java.Interview.PrepSeries;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

class Employeewwewew {
	private String name;
	private double salary;
	private int age;
	private String department;
	private String gender;

	public Employeewwewew(String name, double salary, int age, String department, String gender) {
		this.name = name;
		this.salary = salary;
		this.age = age;
		this.department = department;
		this.gender = gender;
	}

	public String getName() {
		return name;
	}

	public double getSalary() {
		return salary;
	}

	public int getAge() {
		return age;
	}

	public String getDepartment() {
		return department;
	}

	public String getGender() {
		return gender;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee{name='" + name + "', salary=" + salary + ", age=" + age + ", department='" + department
				+ "', gender='" + gender + "'}";
	}
}

public class MapOperationExample {

	public static void main(String[] args) {

		List<Employeewwewew> employees = Arrays.asList(new Employeewwewew("Alice", 50000, 30, "HR", "Female"),
				new Employeewwewew("Bob", 60000, 28, "IT", "Male"),
				new Employeewwewew("Charlie", 75000, 35, "Finance", "Male"),
				new Employeewwewew("Diana", 70000, 32, "IT", "Female"),
				new Employeewwewew("Eve", 55000, 25, "Marketing", "Female"));
//		 employees.stream().map(e -> e.getSalary().add(BigDecimal.valueOf(0.1).multiply(e.getSalary()))).fo
		List<Employeewwewew> incrementingSalaryby10 = employees.stream()
				.peek(emp -> emp.setSalary(emp.getSalary() * 1.10)).collect(Collectors.toList());

		System.out.println("IncrementingSalaryby10 :" + incrementingSalaryby10);

		employees.forEach(e -> e.setSalary(e.getSalary() * 1.10));
		System.out.println("\nList of Employees after salary increase:");
		employees.forEach(System.out::println);

		List<Employeewwewew> incrementingSalaryby10UsingMap = employees.stream().map(s -> {
			s.setSalary(s.getSalary() * 1.10);
			return s;
		}).collect(Collectors.toList());
		System.out.println("IncrementingSalaryby10UsingMap :" + incrementingSalaryby10UsingMap);

		List<String> salarygreaterthan60000 = employees.stream().filter(emp -> emp.getSalary() > 60000)
				.map(Employeewwewew::getName).collect(Collectors.toList());
		System.out.println("Salarygreaterthan60000: " + salarygreaterthan60000);
		
//	List<String> salarygreaterthan60000 =	

//		 employees.stream().filter(emp -> emp.getSalary() > 60000)
//				.forEach(emp -> System.out.println("Emp Name:" + Employeewwewew::getName));

	}
}
