package com.java.InterviewPrep.IntrviePrep;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class CodeDecodeJava8StreamTop20Part1 {

	public static void main(String[] args) {

		List<Integer> IntList = Arrays.asList(5, 6, 3, 2, 1, 7, 8, 9, 10, 4);

		List<Integer> numsGreaterThan5 = IntList.stream().sorted().filter(num -> num > 5).collect(Collectors.toList());
		
		List<Integer> skipMethod = IntList.stream().sorted().skip(5).collect(Collectors.toList());
		System.out.println("SkipMethod :" + skipMethod);
		
		List<Integer> limitMethod = IntList.stream().sorted().limit(5).collect(Collectors.toList());
		System.out.println("LimitMethod :" + limitMethod);

		System.out.println("NumsGreaterThan5 :" + numsGreaterThan5);

		List<String> upperCaseString = Arrays.asList("apple", "java", "springboot", "microservices");
		
		String joiningMethodInsideCollect = upperCaseString.stream().collect(Collectors.joining(", ", "[","]"));
		System.out.println("JoiningMethodInsideCollect : " + joiningMethodInsideCollect);
		
		String[] toArrayMethod = upperCaseString.stream().toArray(String[]::new);
		System.out.println("ToArrayMethod : " + toArrayMethod);
		
		String findFirst = upperCaseString.stream().distinct().filter(str -> str.startsWith("a")).findFirst().get();
		System.out.println("FindFirst :" + findFirst);

		upperCaseString.stream().distinct().map(str -> str.toUpperCase()).forEach(System.out::println);

		upperCaseString.stream().distinct().map(String::toUpperCase).forEach(System.out::println);
		
		//peek method is for debugging
		List<String> peekMethod = upperCaseString.stream().peek(word -> System.out.println("Original :" + word)).map(String::toUpperCase)
				.collect(Collectors.toList());
		System.out.println("PeekMethod :" + peekMethod);
		
		Optional<Integer> reduceMethod = IntList.stream().reduce((a, b) -> a*b);
		System.out.println(reduceMethod);
		
		boolean allMatchCheckingAllPositive = IntList.stream().allMatch(n -> n>0);
		System.out.println("AllMatchCheckingAllPositive :" + allMatchCheckingAllPositive);
		
		boolean noneMatchCheckingAllNegative = IntList.stream().noneMatch(n -> n<0);
		System.out.println("NoneMatchCheckingAllNegative :" + noneMatchCheckingAllNegative);
		
	}

}
