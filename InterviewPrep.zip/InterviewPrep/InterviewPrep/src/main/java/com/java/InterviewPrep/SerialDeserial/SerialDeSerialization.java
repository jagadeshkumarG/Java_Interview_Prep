package com.java.InterviewPrep.SerialDeserial;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerialDeSerialization {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
		Jagha jagha = new Jagha();
		
		jagha.setAge(25);
		jagha.setName("Jagadesh");
		
		// Serialization
		
		FileOutputStream fileOutputStream = new FileOutputStream("C:\\Users\\ramki\\OneDrive\\Desktop\\serializableFile.ser");
		ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
		objectOutputStream.writeObject(jagha);
		objectOutputStream.close();
		fileOutputStream.close();
		
		//De-Serialization
		
		FileInputStream fileInputStream = new FileInputStream("C:\\Users\\ramki\\OneDrive\\Desktop\\serializableFile.ser");
		ObjectInputStream inputStream = new ObjectInputStream(fileInputStream);
		Jagha reCreateObj = (Jagha) inputStream.readObject();
		System.out.println(reCreateObj.getName());
		inputStream.close();
		fileInputStream.close();
		

	}

}
