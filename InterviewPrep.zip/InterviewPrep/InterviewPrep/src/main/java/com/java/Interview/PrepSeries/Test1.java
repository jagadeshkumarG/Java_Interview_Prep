package com.java.Interview.PrepSeries;

public interface Test1 {
	
default void display() {
		
	}

}
