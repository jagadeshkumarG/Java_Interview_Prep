package com.java.InterviewPrep.IntrviePrep;

import java.util.Stack;

public class ReverseStringUsingDSA {
    public static void main(String[] args) {
        String input = "Hello, World!";
        
        // Create a stack to hold characters
        Stack<Character> stack = new Stack<>();
        
        // Push all characters of the string onto the stack
        for (int i = 0; i < input.length(); i++) {
            stack.push(input.charAt(i));
        }

        // Create an empty string to store the reversed string
        StringBuilder reversed = new StringBuilder();
        
        // Pop each character from the stack and append to the reversed string
        while (!stack.isEmpty()) {
            reversed.append(stack.pop());
        }

        // Output the reversed string
        System.out.println("Reversed string: " + reversed.toString());
    }
}

