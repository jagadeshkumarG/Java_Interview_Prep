package com.java.InterviewPrep.Interviewssss;

import java.util.Arrays;
import java.util.Comparator;

public class KPMG {

	public static void main(String[] args) {

		int[] arr = { 1, 2, 3, 4, 5 };

		Integer lowestEven = Arrays.stream(arr).filter(num -> num % 2 == 0).boxed().sorted(Comparator.reverseOrder()).skip(1).findFirst()
				.get();
		System.out.println("lowestEven : " + lowestEven);

	}

}
