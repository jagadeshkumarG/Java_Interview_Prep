package com.java.InterviewPrep.Interviewssss;

public class PerficientSingleTon {

	private static volatile PerficientSingleTon instance;

	private PerficientSingleTon() {
	}

	public static PerficientSingleTon getPerficientSingleTon() {

		if (instance == null) {
			synchronized (PerficientSingleTon.class) {
				if (instance == null) {
					instance = new PerficientSingleTon();
				}
			}
		}
		return instance;
	}

	public static void main(String[] args) {
//		Double secondHighestSalary = empList.stream().map(Employee::getSalary())
//				.sorted(Comparator.reversedOreder()).skip(1).findFirst().get();
	}

}
