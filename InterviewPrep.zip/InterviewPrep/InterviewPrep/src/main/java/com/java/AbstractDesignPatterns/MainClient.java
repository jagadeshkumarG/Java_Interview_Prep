package com.java.AbstractDesignPatterns;

public class MainClient {

	public static void main(String[] args) {

		AbstractorFactoryProducer abstractorFactoryProducer = new AbstractorFactoryProducer();
		AbstractFactory factoryObj = abstractorFactoryProducer.getAbstractFactory("Luxary");
		Car carObj = factoryObj.getInstance(1500000);
		System.out.println(carObj.getTopSpeed());
	}

}
