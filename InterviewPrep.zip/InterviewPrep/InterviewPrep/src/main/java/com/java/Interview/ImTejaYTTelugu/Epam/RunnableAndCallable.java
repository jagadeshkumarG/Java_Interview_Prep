package com.java.Interview.ImTejaYTTelugu.Epam;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

class MyRunnable implements Runnable {

	@Override
	public void run() {
		System.out.println("Runnable is Running...");
	}

}

class MyCallable implements Callable<String> {

	@Override
	public String call() throws Exception {
		return "Callable Completed...,";
	}

}

public class RunnableAndCallable {

	public static void main(String[] args) throws InterruptedException, ExecutionException {

		Thread t1 = new Thread(new MyRunnable());
		t1.start();
		ExecutorService es = Executors.newSingleThreadExecutor();
		es.execute(new MyRunnable());
		Future<String> future = es.submit(new MyCallable());
		String result = future.get();
		es.shutdown();
		System.out.println(result);

	}

}
