package com.java.AbstractDesignPatterns;

public class EcnomicCarFactory implements AbstractFactory {

	@Override
	public Car getInstance(int price) {
		if (price <= 450000) {
			return new EcnomicCar1();
		} else if (price > 500000) {
			return new EcnomicCar2();
		}
		return null;
	}

}
