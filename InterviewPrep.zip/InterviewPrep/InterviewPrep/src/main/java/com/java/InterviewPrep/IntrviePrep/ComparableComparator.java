package com.java.InterviewPrep.IntrviePrep;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import lombok.Data;
@Data
class Student {
	int age;
	String name;

	public String toString() {
		return "Student{" + "age=" + age + ", name='" + name + '\'' + '}';
	}

	public Student(int age, String name) {
		this.age = age;
		this.name = name;
	}

	
//	public int compareTo(Student that) {
//		return this.age - that.age;
//	}
	
	public int compareTo(Student stu) {
		if(this.age == stu.age ) {
			return 0;
		} else if (age > stu.age) {
			return 1;
		} else {
			return -1;
		}
	}
}

public class ComparableComparator {


	public static void main(String[] args) {
		
		Comparator<Student> studsCom = (i, o) -> 
				i.age > o.age?1:-1	;

		List<Student> studs = new ArrayList<>();
		studs.add(new Student(21, "Jagha"));
		studs.add(new Student(27, "Vachu"));
		studs.add(new Student(31, "Pranu"));
		studs.add(new Student(29, "Kyathi"));

		Collections.sort(studs, studsCom);
		System.out.println(studs);
	}
}
