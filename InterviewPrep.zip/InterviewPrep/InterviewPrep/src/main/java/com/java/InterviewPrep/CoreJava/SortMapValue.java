package com.java.InterviewPrep.CoreJava;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class SortMapValue {

	public static void main(String[] args) {

		Map<String, Integer> map = new HashMap<>();

		map.put("A", 10);
		map.put("B", 30);
		map.put("C", 20);
		map.put("D", 70);
		map.put("E", 50);
		map.put("F", 60);
		map.put("G", 40);

		LinkedHashMap<String, Integer> mapSorting = map.entrySet().stream().sorted(Map.Entry.comparingByValue())
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));

		mapSorting.forEach((e1, e2) -> System.out.println(e1 + " -> " + e2));

	}

}
