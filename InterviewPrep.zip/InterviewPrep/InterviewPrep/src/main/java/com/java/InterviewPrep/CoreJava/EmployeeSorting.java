package com.java.InterviewPrep.CoreJava;

import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

public class EmployeeSorting {

	private int id;
	private String name;
	private double salary;

	public EmployeeSorting(int id, String name, double salary) {
		this.id = id;
		this.name = name;
		this.salary = salary;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, name, salary);
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmployeeSorting other = (EmployeeSorting) obj;
		return id == other.id && Objects.equals(name, other.name)
				&& Double.doubleToLongBits(salary) == Double.doubleToLongBits(other.salary);
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public double getSalary() {
		return salary;
	}

	@Override
	public String toString() {
		return "EmployeeSorting{id=" + id + ", name='" + name + "', salary=" + salary + '}';
	}

	public static void main(String[] args) {
		Map<Integer, EmployeeSorting> employeeMap = new HashMap<>();
		employeeMap.put(1, new EmployeeSorting(1, "Alice", 50000));
		employeeMap.put(2, new EmployeeSorting(2, "Bob", 70000));
		employeeMap.put(3, new EmployeeSorting(3, "Charlie", 60000));
		employeeMap.put(4, new EmployeeSorting(4, "David", 80000));

		Set<EmployeeSorting> studentSet = new HashSet<>();
		studentSet.add(new EmployeeSorting(1, "John", 85));
		studentSet.add(new EmployeeSorting(2, "Emma", 90));
		studentSet.add(new EmployeeSorting(3, "Sophia", 75));
		studentSet.add(new EmployeeSorting(4, "Michael", 95));

		LinkedHashSet<EmployeeSorting> sortBySal = studentSet.stream()
				.sorted(Comparator.comparingDouble(EmployeeSorting::getSalary)).filter(emp -> emp.getSalary() >= 85)
				.collect(Collectors.toCollection(LinkedHashSet::new));
		System.out.println(sortBySal);

//		sortBySal.forEach(System.out::println);

	}

}
