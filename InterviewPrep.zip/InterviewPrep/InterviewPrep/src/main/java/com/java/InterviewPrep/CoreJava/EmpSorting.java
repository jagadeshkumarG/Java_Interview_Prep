package com.java.InterviewPrep.CoreJava;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

class Empatloyee {
	private String name;
	private double salary;
	private int age;
	private String department;

	public Empatloyee(String name, double salary, int age, String department) {
		this.name = name;
		this.salary = salary;
		this.age = age;
		this.department = department;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	@Override
	public String toString() {
		return "Empatloyee{Name: " + name + ", Salary: $" + salary + ", Age: " + age + ", Department: " + department
				+ "}";
	}
}

public class EmpSorting {

	public static void main(String[] args) {

		List<Empatloyee> employees = new ArrayList<>();

		employees.add(new Empatloyee("John Doe", 60000, 28, "Marketing"));
		employees.add(new Empatloyee("Jane Smith", 75000, 35, "Engineering"));
		employees.add(new Empatloyee("Alice Johnson", 55000, 42, "HR"));
		employees.add(new Empatloyee("Robert Brown", 90000, 50, "Finance"));
		employees.add(new Empatloyee("Sarah Williams", 65000, 29, "HR"));
		employees.add(new Empatloyee("Michael Davis", 80000, 38, "Operations"));
		employees.add(new Empatloyee("Emily Clark", 70000, 32, "Operations"));
		employees.add(new Empatloyee("David White", 72000, 45, "Finance"));
		employees.add(new Empatloyee("Sophia Green", 58000, 40, "Marketing"));
		employees.add(new Empatloyee("Mark Taylor", 85000, 47, "Engineering"));

		List<String> distinctList = employees.stream().map(Empatloyee::getDepartment).distinct()
				.collect(Collectors.toList());
		System.out.println(distinctList);

		

		
//        .forEach(System.out::println);

		// employee with salary more than 65000 and sort them with age

		List<Empatloyee> agewithSalary = employees.stream().filter(Emp -> Emp.getSalary() > 65000)
				.sorted(Comparator.comparingInt(Empatloyee::getAge)).distinct().collect(Collectors.toList());

		System.out.println(agewithSalary);

		// employee with dist depar avg salary

//		employees.stream().map(Empatloyee::getDepartment).distinct()
//				.collect(Collectors.groupingBy(Empatloyee::getAge, Collectors.averagingInt(Empatloyee::getSalary)));
//		distinctList.stream().collect(Collectors.groupingBy(Empatloyee::getDepartment, Collectors.averagingInt(Empatloyee::getSalary)));

	}

}
