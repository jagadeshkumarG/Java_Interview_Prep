package com.java.InterviewPrep.Interviewssss;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Concentrix {

	public static void main(String[] args) {

		List<Integer> list = Arrays.asList(1, 2, 2, 2, null, 3, 3, 5, 5, 5, 5);

		Map<Integer, Long> map = list.stream().filter(n -> n != null)
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

		System.out.println("temp :" + map);

		Entry<Integer, Long> entry = map.entrySet().stream()
				.sorted(Map.Entry.<Integer, Long>comparingByValue(Comparator.reverseOrder())).skip(1).findFirst().get();

		System.out.println("entry :" + entry.getKey());

	}

}
