package com.java.Interview.ImTejaYTTelugu.Epam;

public class Occurance {

	public static long countOccurances(String input, String targetWord) {

		/*
		 * return Arrays.stream(input.split(";")).map(String::trim) .filter(word ->
		 * word.equalsIgnoreCase(targetWord)).count();
		 */

		String[] str = input.split(";");

		int count = 0;
		for (String word : str) {

			if (word.trim().equalsIgnoreCase(targetWord)) {
				count++;
			}
		}
		return count;

	}

	public static void main(String[] args) {
		String input1 = "critical; verbal; spital";
		String input2 = "critical; verbal; critical";

		System.out.println("Output1 : " + countOccurances(input1, "critical"));
		System.out.println("Output1 : " + countOccurances(input2, "critical"));
	}

}
