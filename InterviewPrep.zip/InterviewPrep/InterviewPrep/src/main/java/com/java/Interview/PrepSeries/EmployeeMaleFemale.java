package com.java.Interview.PrepSeries;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class EmployeeMaleFemale {

	public static void main(String[] args) {

		List<Employee> employees = Arrays.asList(new Employee(101, "John Doe", "HR", "Male", 50000.00),
				new Employee(102, "Alice", "IT", "Female", 60000.00),
				new Employee(103, "Sam Brown", "Finance", "Male", 55000.00),
				new Employee(104, "Jane", "HR", "Female", 62000.00),
				new Employee(105, "David Wilson", "Sales", "Male", 48000.00));

//		List<Employee> employees = new ArrayList<>();

		long maleCount = employees.stream().filter(emp -> emp.getGender() == "Male").count();
		System.out.println("maleCount :" + maleCount);
		
		Map<String, Long> genderCount = employees.stream().collect(Collectors.groupingBy(Employee::getGender, Collectors.counting()));
		
		System.out.println("Number of Male Employees: " + genderCount.getOrDefault("Male", 0L));
        System.out.println("Number of Female Employees: " + genderCount.getOrDefault("Female", 0L));

	}

}
