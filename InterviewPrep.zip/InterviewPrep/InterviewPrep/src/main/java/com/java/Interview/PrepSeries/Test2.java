package com.java.Interview.PrepSeries;

public interface Test2 {
	
	default void display() {
		
	}

}
