package com.java.InterviewPrep.Interviewssss;

import java.util.Scanner;
import java.util.stream.IntStream;

public class PalindromePersistant {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		String input = sc.nextLine();

		String chars = input.replaceAll("\s", "");

//		String str = "madam";

		boolean isPalindrome = IntStream.rangeClosed(0, chars.length() / 2)
				.allMatch(a -> chars.charAt(a) 
						== chars.charAt(chars.length() - 1 - a));
		System.out.println("isPalindrome : " + isPalindrome);
		sc.close();

	}

}
