package com.java.Interview.PrepSeries;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class LongestString {

	public static void main(String[] args) {

		List<String> words = Arrays.asList("Java", "Stream", "API", "Development");

		words.stream().map(String::length).forEach(System.out::println); // finding Lengths

		String maxLength = words.stream().max(Comparator.comparingInt(String::length)).orElse(null);
		System.out.println("maxLength : " + maxLength);
		String longestString = words.stream()
                .max((word1, word2) -> Integer.compare(word1.length(), word2.length()))
                .orElse(null);
		System.out.println("longestString : " + longestString);
		String longestWord = words.stream()
                .reduce((word1, word2) -> word1.length() > word2.length() ? word1 : word2)
                .orElse(null);
		System.out.println("longestWord : " + longestWord);

	}

}
