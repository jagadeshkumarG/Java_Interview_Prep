package com.java.InterviewPrep.Interviewssss;

import java.io.IOException;

public class KPMGClassA {

	class A {

		public int method1() {

			System.out.println("method1");

			return 1;

		}

	}

	class B extends A {

		public int method1() throws RuntimeException {

			System.out.println("method2");

			return 1;

		}

	}

	public class Override {

		public static void main(String[] args) throws IOException {

			A a = new B();

			a.method1();

		}

	}

}
