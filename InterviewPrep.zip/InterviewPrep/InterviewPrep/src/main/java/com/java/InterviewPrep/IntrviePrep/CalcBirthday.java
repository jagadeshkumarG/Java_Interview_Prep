package com.java.InterviewPrep.IntrviePrep;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class CalcBirthday {

    public static void main(String[] args) {

        LocalDate birthday = LocalDate.of(1997, 10, 07);
        //System.out.println(birthday);
        LocalDate now = LocalDate.now();
        System.out.println(ChronoUnit.YEARS.between(birthday, now));
    }
}
