package com.java.InterviewPrep.CoreJava;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PrintEvenOddNumsByThread {

	public static void main(String[] args) {
			
		
		ExecutorService executor = Executors.newFixedThreadPool(2);
		
		
	}

}
