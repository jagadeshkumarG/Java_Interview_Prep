package com.java.Interview.PrepSeries;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class ParallelStreamExample {
	public static void main(String[] args) {
		List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9);

		long startTime = System.currentTimeMillis();
		Stream<Integer> map = numbers.parallelStream().map(n -> {
			System.out.println(Thread.currentThread().getName() + " - " + n);
			return n * n;
		});
		long endTime = System.currentTimeMillis();
		System.out.println("Sequential Stream Time: " + (endTime - startTime) + " ms");
//		.forEach(n -> System.out.println("Square: " + n));

		long startTimee = System.currentTimeMillis();
		numbers.parallelStream().map(n -> {
			System.out.println(Thread.currentThread().getName() + " - " + n);
			return n * n;
		});
		long endTimee = System.currentTimeMillis();
		System.out.println("Parallel Stream Time: " + (endTimee - startTimee) + " ms");

//		.forEach(n -> System.out.println("Square: " + n));

		List<Integer> numbers1 = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

		// Using parallelStream to sum the elements
		int sum = numbers1.parallelStream().mapToInt(Integer::intValue).sum();

		System.out.println("Sum: " + sum);
	}
}
