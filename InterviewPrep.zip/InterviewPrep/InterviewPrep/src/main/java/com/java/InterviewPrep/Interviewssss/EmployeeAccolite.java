package com.java.InterviewPrep.Interviewssss;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class EmployeeAccolite {

	private String name;
	private double salary;

	public EmployeeAccolite(String name, double salary) {
		super();
		this.name = name;
		this.salary = salary;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public static void main(String[] args) {

		List<EmployeeAccolite> emp = Arrays.asList(new EmployeeAccolite("Sujan", 10000.00),
				new EmployeeAccolite("Jagha", 20000.00), new EmployeeAccolite("Astha", 30000.00),
				new EmployeeAccolite("Swarna", 40000.00));

		// second Highest salary using Java 8

		Optional<Double> secondHigestSal = emp.stream()
				.sorted(Comparator.comparingDouble(EmployeeAccolite::getSalary).reversed()).skip(1)
				.map(EmployeeAccolite::getSalary).findFirst();
		System.out.println("secondHigestSal : " + secondHigestSal);

//		maxSalary.ifPresent(emp -> { System.out.println("Highest Salary of Emp"));

		List<EmployeeAccolite> empSortBynameandSalary = emp.stream()
				.sorted(Comparator.comparing(EmployeeAccolite::getName, Comparator.reverseOrder())
						.thenComparing(EmployeeAccolite::getSalary, Comparator.reverseOrder()))
				.collect(Collectors.toList());
	}

}
