package com.java.Interview.ImTejaYTTelugu.Epam;

public class LakshmanReddy {

	public static void main(String[] args) {
		// Let's say you have a list of Employee objects. Each employee has an age
		// field. Can you write a stream-based code snippet to get all employees older
		// than 30?

//		empList.stream().filter(emp-> emp.getAge() > 30).collect(Collectors.toList());

		// Suppose you have a list of products with name and price. How would you sort
		// the products in ascending order of price using Java 8 streams?

//		List<Product> sortedByPrice = products.stream()
//			    .sorted(Comparator.comparing(Product::getPrice))
//			    .collect(Collectors.toList());

//		List<Product> sortedByPrice = products.stream()
//	    .sorted(Comparator.comparing(Product::getPrice).reversed()) // descending order
//	    .collect(Collectors.toList());

//		Imagine some entries in your list might have null names. 
//		How would you sort the list but push all entries with null names to the end?
		
//		List<Product> sortedByNameNullsLast = products.stream()
//	            .sorted(Comparator.comparing(Product::getName, Comparator.nullsLast(String::compareTo)))
//	            .collect(Collectors.toList());

	}

}
