package com.java.InterviewPrep.CoreJava;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class SampleCodingQuesInChromeSS {

	public static void main(String[] args) {

		// Seperate Odd and Even
		List<Integer> nums = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
		List<Integer> filterMethEveOdd = nums.stream().filter(num -> num % 2 == 0).collect(Collectors.toList());

		Map<Boolean, List<Integer>> partiEveOdd = nums.stream().collect(Collectors.partitioningBy(num -> num % 2 == 0));

		List<Integer> evenNum = partiEveOdd.get(true);
		List<Integer> oddNum = partiEveOdd.get(false);

		// Max and Min from list

		Integer max = nums.stream().max(Comparator.naturalOrder()).get();
		System.out.println("MAX :" + max);
		Integer min = nums.stream().min(Comparator.naturalOrder()).get();
		System.out.println("MIN :" + min);

		// nums.stream().sorted().limit(3).skip(1).forEach(System.out::println);

		// frequency of each char of string

		String input = "ilovejavatechie";

		Map<Character, Long> freqOfString = input.chars().mapToObj(c -> (char) c)
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		System.out.println("FreqOfString :" + freqOfString);

		String[] split = input.split("");

		Map<String, Long> freqOfString1 = Arrays.stream(split)
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

		System.out.println("freqOfString1 : " + freqOfString1);

		freqOfString1.entrySet().stream().filter(word -> word.getValue() > 1)
				.forEach((word) -> System.out.println(word.getKey() + " -> " + word.getValue()));

	}

}
