package com.java.InterviewPrep.CoreJava;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class PalindromesSort {
	
	public static boolean isPalindrome(String str) {
		
		int left = 0; int right = str.length()-1;
		
		while(left < right) {
			if(str.charAt(left++) != str.charAt(right--)) return false;
		}	
		return true;
	}

	public static void main(String[] args) {
		
		String str = "madam";
		
		System.out.println(isPalindrome(str));
			
		
		List<String> words = Arrays.asList("madam", "apple", "level", "banana", "radar");
		
		List<String> sortedWords = words.stream()
                .sorted(Comparator.comparing((String s) -> s.equals(new StringBuilder(s).reverse().toString()) ? 0 : 1)
                        .thenComparing(Comparator.naturalOrder()))
                .collect(Collectors.toList());

        System.out.println(sortedWords);
		
//		words.stream().sorted(Comparator.comparing((String s) -> s.equals(new StringBuilder(s).reverse()toString() ? 0 :1))
//				.th
	}

}
