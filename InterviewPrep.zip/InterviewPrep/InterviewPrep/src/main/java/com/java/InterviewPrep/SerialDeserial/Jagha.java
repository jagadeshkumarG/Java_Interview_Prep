package com.java.InterviewPrep.SerialDeserial;

import java.io.Serializable;
import java.util.Objects;

import lombok.Data;

@Data
public class Jagha implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int age;
	private String name;
	@Override
	public int hashCode() {
		return Objects.hash(age, name);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Jagha other = (Jagha) obj;
		return age == other.age && Objects.equals(name, other.name);
	}
	public Jagha() {
		super();
		this.age = age;
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

}
