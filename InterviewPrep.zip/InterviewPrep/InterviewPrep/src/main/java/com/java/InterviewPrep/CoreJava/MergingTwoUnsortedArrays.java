 package com.java.InterviewPrep.CoreJava;

import java.util.Arrays;
import java.util.stream.IntStream;

public class MergingTwoUnsortedArrays {

	public static void main(String[] args) {
		
		int[] a = {1, 2, 3, 4};
		
		int[] b = {5, 6, 7, 8};
		
		int[] mergedArray = IntStream.concat(Arrays.stream(a), Arrays.stream(b)).sorted().toArray();
		
		System.out.println("mergedArray :" + mergedArray);
		
		//Stream.concat(Arrays.stream(a), Arrays.stream(b)).sorted().toArray();
		
		
	}

}
