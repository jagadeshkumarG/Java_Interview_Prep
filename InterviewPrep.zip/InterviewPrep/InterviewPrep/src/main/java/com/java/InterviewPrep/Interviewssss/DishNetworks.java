package com.java.InterviewPrep.Interviewssss;

import java.util.Stack;

public class DishNetworks {

	public static void main(String[] args) {
		
//		O Input: (a + (b*c)) + (d/e)
//		O Output: 122133

		String expression = "(a + (b*c)) + (d/e)";

		Stack<Integer> stack = new Stack<Integer>();
		StringBuilder output = new StringBuilder();
		int count = 0;

//		int openBraces = 0;
//		int closedBraces = 0;
		for (char c : expression.toCharArray()) {
			if (c == '(') {
				count++;
				// openBraces++;
				stack.push(count);
				output.append(count);
			} else if (c == ')') {
				// closedBraces++;
				output.append(stack.peek());
				stack.pop();
//				count--;
			}

		}
		System.out.println(output.toString());

	}
}
