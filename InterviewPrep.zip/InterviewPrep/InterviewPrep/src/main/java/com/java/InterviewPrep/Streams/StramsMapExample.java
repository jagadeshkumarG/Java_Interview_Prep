package com.java.InterviewPrep.Streams;

import com.java.InterviewPrep.Data.StudentDataBase;
import com.java.InterviewPrep.Data.Student;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class StramsMapExample {

    public static List<String> namesList() {

        List<String> studentListStream = StudentDataBase.getAllStudents().stream().map(Student::getName)
                .map(String::toUpperCase).collect(Collectors.toList());
        return studentListStream;

    }

    public static Set<String> namesSet() {

        Set<String> studentSetStream = StudentDataBase.getAllStudents().stream().map(Student::getName)
                .map(String::toLowerCase).collect(Collectors.toSet());
        return studentSetStream;

    }

    public static void main(String[] args) {
        System.out.println(namesList());

        System.out.println(namesSet());

    }

}
