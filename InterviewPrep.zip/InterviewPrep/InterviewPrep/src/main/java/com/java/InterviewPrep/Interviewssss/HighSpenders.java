package com.java.InterviewPrep.Interviewssss;

import java.util.*;

public class HighSpenders {
    public static List<String> processData(List<String> inputData) {
        Map<String, Integer> storeMaxPrice = new HashMap<>(); // Store -> Max price
        Map<String, Set<String>> storeHighSpenders = new HashMap<>(); // Store -> Set of customers
        
        for (String entry : inputData) {
            String[] parts = entry.split(", ");
            String customer = parts[0];
            String store = parts[1];
            int price = Integer.parseInt(parts[4].replace("Rs ", ""));
            
            storeMaxPrice.putIfAbsent(store, 0);
            storeHighSpenders.putIfAbsent(store, new HashSet<>());
            
            int maxPrice = storeMaxPrice.get(store);
            if (price > maxPrice) {
                storeMaxPrice.put(store, price);
                storeHighSpenders.get(store).clear();
                storeHighSpenders.get(store).add(customer);
            } else if (price == maxPrice) {
                storeHighSpenders.get(store).add(customer);
            }
        }
        
        Set<String> result = new TreeSet<>(); // Use TreeSet to maintain sorted order
        for (Set<String> customers : storeHighSpenders.values()) {
            result.addAll(customers);
        }
        
        return new ArrayList<>(result);
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<String> inputData = new ArrayList<>();
        
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            if (line.isEmpty()) break;
            inputData.add(line);
        }
        scanner.close();
        
        List<String> result = processData(inputData);
        for (String name : result) {
            System.out.println(name);
        }
    }
}
