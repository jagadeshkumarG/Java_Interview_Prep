package com.java.Interview.ImTejaYTTelugu.Epam;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class HashMapToArrayList {

	public static void main(String[] args) {

		HashMap<Integer, String> map = new HashMap<>();
		map.put(1, "Java");
		map.put(2, "Spring boot");
		map.put(3, "Microservices");
		map.put(4, "SQL");

		ArrayList<String> valueList = new ArrayList<>(map.values());
		System.out.println("valueList : " + valueList);

		ArrayList<Integer> keyList = new ArrayList<>(map.keySet());
		System.out.println("keyList : " + keyList);

		ArrayList<Map.Entry<Integer, String>> entrySet = new ArrayList<>(map.entrySet());
		for (Map.Entry<Integer, String> entry : entrySet) {
			System.out.println(entry.getKey() + " : " + entry.getValue());
		}
//		entrySet.forEach((entry) -> System.out.println(entry.getKey() + " : " + entry.getValue()));
	}

}
