package ProtoTypeDesignPattern;

public class Main {

	public static void main(String[] args) {

		Student obj = new Student("Jagadesh", 143, 25);

		Student cloneObj = (Student) obj.clone();
	}

}
