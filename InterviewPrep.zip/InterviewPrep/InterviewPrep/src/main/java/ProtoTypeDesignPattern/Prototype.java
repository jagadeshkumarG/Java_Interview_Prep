package ProtoTypeDesignPattern;

public interface Prototype {

	Prototype clone();

}
