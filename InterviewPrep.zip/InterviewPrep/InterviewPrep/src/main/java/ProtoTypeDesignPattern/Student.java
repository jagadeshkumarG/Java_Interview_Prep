package ProtoTypeDesignPattern;

public class Student implements Prototype {

	String name;
	private int rollNumber;
	int age;

	Student(String name, int rollNumber, int age) {
		super();
		this.name = name;
		this.rollNumber = rollNumber;
		this.age = age;
	}

	@Override
	public Prototype clone() {
		return new Student("Jagadesh", 143, 25);
	}

}
